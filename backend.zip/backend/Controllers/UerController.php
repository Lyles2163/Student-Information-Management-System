<?php
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // 处理预检请求
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type");
    exit(0);  // 提前结束请求，避免进入后续代码
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

require_once '../config.php'; // 引入数据库配置
require_once '../models/UserModel.php'; // 引入用户模型

class UserController {
    private $model;

    public function __construct() {
        // 初始化用户模型
        $this->model = new UserModel($GLOBALS['pdo']);
    }

    // 获取所有用户数据
    public function getUsers() {
        try {
            // 从模型中获取用户数据
            $users = $this->model->getUsers();

            // 返回 JSON 格式的数据
            echo json_encode($users);
        } catch (Exception $e) {
            // 发生错误时返回错误信息
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    // 根据 ID 获取用户数据
    public function getUserById($id) {
        try {
            // 从模型中获取指定用户的数据
            $user = $this->model->getUserById($id);

            // 如果用户存在，返回用户数据
            if ($user) {
                echo json_encode($user);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'User not found']);
            }
        } catch (Exception $e) {
            // 发生错误时返回错误信息
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}
?>
