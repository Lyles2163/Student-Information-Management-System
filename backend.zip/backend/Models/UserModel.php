<?php
class UserModel {
    private $pdo;

    // 构造函数，接收数据库连接
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // 获取所有用户数据
    public function getUsers() {
        // SQL 查询语句
        $sql = "SELECT id, username, age, userAccount, avatarUrl, gender, createTime, userRole FROM user";

        // 准备并执行查询
        $stmt = $this->pdo->query($sql);

        // 获取所有数据并返回
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 根据用户ID获取用户数据
    public function getUserById($id) {
        $sql = "SELECT id, username, age, userAccount, avatarUrl, gender, createTime, userRole FROM user WHERE id = :id";

        // 准备 SQL 语句
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);

        // 返回查询结果
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>
