<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once 'config.php';

try {
    // 获取前端传递的用户数据
    $data = json_decode(file_get_contents("php://input"), true);

    // 验证数据
    if (!$data['username'] || !$data['avatarUrl'] || !$data['userAccount'] || !$data['userPassword'] || !$data['age']) {
        echo json_encode([
            "code" => 400,
            "msg" => "数据不完整"
        ]);
        exit;
    }

    // 插入数据到数据库
    $sql = "INSERT INTO user (username, avatarUrl, userAccount, userPassword, gender, age, userRole) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $data['username'],
        $data['avatarUrl'],
        $data['userAccount'],
        $data['userPassword'],
        $data['gender'],
        $data['age'],
        $data['userRole']
    ]);

    echo json_encode([
        "code" => 200,
        "msg" => "用户添加成功"
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "code" => 500,
        "msg" => "数据库操作失败：" . $e->getMessage()
    ]);
}
?>
