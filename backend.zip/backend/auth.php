<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// 预检请求处理
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 引入数据库配置
include 'config.php';

// 获取前端传参
$data = json_decode(file_get_contents("php://input"), true);
$action = $data['action'] ?? ''; // 区分 'send_code' 和 'register'

// 验证码发送逻辑
if ($action === 'send_code') {
    $phone = $data['phone'] ?? '';

    // 校验手机号格式
    if (!preg_match("/^1[3-9]\d{9}$/", $phone)) {
        echo json_encode(["status" => "error", "message" => "手机号格式不正确"]);
        exit();
    }

    // 生成验证码并存储到 SESSION
    $code = rand(1000, 9999);
    $_SESSION['mobile_code'] = $code;
    $_SESSION['mobile'] = $phone;
    $_SESSION['code_expiry'] = time() + 300; // 验证码5分钟有效

    // 模拟发送验证码（这里用日志替代发送短信）
    error_log("验证码发送至 {$phone}: {$code}");

    echo json_encode(["status" => "success", "message" => "验证码已发送"]);
    exit();
}

// 注册逻辑
if ($action === 'register') {
    $userAccount = $data['userAccount'] ?? '';
    $password = $data['password'] ?? '';
    $confirmPassword = $data['confirmPassword'] ?? '';
    $phone = $data['phone'] ?? '';
    $code = $data['code'] ?? '';

    // 校验验证码
    if (
        !isset($_SESSION['mobile_code']) ||
        !isset($_SESSION['mobile']) ||
        time() > $_SESSION['code_expiry'] ||
        $_SESSION['mobile'] !== $phone ||
        $_SESSION['mobile_code'] != $code
    ) {
        echo json_encode(["status" => "error", "message" => "验证码不正确或已过期"]);
        exit();
    }

    // 校验密码是否一致
    if ($password !== $confirmPassword) {
        echo json_encode(["status" => "error", "message" => "密码和确认密码不一致"]);
        exit();
    }

    // 检查账号是否存在
    $sql = "SELECT id FROM user WHERE userAccount = :userAccount";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['userAccount' => $userAccount]);
    if ($stmt->rowCount() > 0) {
        echo json_encode(["status" => "error", "message" => "账号已存在"]);
        exit();
    }
// 默认数据
    $age = 20;
    $avatarUrl = 'assets/media/classImg/test男.jpg'; // 默认头像URL
    $gender = '女'; // 默认性别
    $userRole = 0; // 默认用户角色

// 插入用户数据（密码直接保存，不加密）
    $sql = "INSERT INTO user (username, age, userAccount, avatarUrl, gender, userPassword, userRole) 
        VALUES (:username, :age, :userAccount, :avatarUrl, :gender, :userPassword, :userRole)";
    $stmt = $pdo->prepare($sql);

    $params = [
        'username' => 'user' . rand(100000, 999999), // 自动生成用户名 (user + 随机6位数字)
        'age' => $age,
        'userAccount' => $userAccount,
        'avatarUrl' => $avatarUrl,
        'gender' => $gender,
        'userPassword' => $password, // 直接保存密码
        'userRole' => $userRole
    ];
    if ($stmt->execute($params)) {
        echo json_encode(["status" => "success", "message" => "注册成功"]);
        unset($_SESSION['mobile_code']); // 注册成功后销毁验证码
    } else {
        echo json_encode(["status" => "error", "message" => "注册失败，请稍后重试"]);
    }
    exit();
}

echo json_encode(["status" => "error", "message" => "无效请求"]);
exit();
?>
