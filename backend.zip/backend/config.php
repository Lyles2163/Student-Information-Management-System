<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
try {
    $pdo = new PDO(
        "mysql:host=localhost;port=3308;dbname=vue;charset=utf8mb4",
        "root", // 用户名
        ""     // 密码
    );
    // 设置 PDO 的错误模式为异常模式
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // 捕获连接错误并输出错误信息
    die("Database connection failed: " . $e->getMessage());
}

?>
