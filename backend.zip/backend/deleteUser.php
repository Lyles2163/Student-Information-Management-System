<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// 引用数据库配置文件
require_once 'config.php';  // 确保路径正确

try {
    // 获取传入的用户ID
    $userId = isset($_GET['id']) ? $_GET['id'] : null;

    // 如果没有传递用户ID，返回错误
    if (!$userId) {
        echo json_encode([
            "code" => 400,
            "msg" => "用户ID未提供"
        ]);
        exit;
    }

    // 删除用户
    $sql = "DELETE FROM user WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $userId]);

    echo json_encode([
        "code" => 200,
        "msg" => "用户删除成功"
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "code" => 500,
        "msg" => "数据库连接失败：" . $e->getMessage()
    ]);
}
?>
