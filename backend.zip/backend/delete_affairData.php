<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// 处理 OPTIONS 请求（CORS 预检请求）
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config.php'; // 数据库连接配置

// 调试日志函数
function logDebug($message) {
    file_put_contents('debug.log', $message . "\n", FILE_APPEND);
}

// 检查请求数据
$inputJSON = file_get_contents('php://input'); // 原始 JSON 数据
$input = json_decode($inputJSON, true); // 解析 JSON 数据

// 兼容 application/x-www-form-urlencoded 和 application/json
$table = $input['table'] ?? $_POST['table'] ?? '';
$id = $input['id'] ?? $_POST['id'] ?? null;

// 写入日志：打印传入的原始数据和解析结果
logDebug("Raw JSON Data: $inputJSON");
logDebug("POST Data: " . print_r($_POST, true));
logDebug("Table: '$table', ID: '$id'");

// 支持的表名和主键字段映射
$tableMap = [
    'user_dynamic' => 'dynamicId',
    'user_event' => 'eventId',
    'user_homework' => 'homeworkId',
    'user_notification' => 'notificationId',
];

// 验证表名是否合法
if (!array_key_exists($table, $tableMap)) {
    logDebug("Invalid Table Name: '$table'");
    echo json_encode(['status' => 'error', 'message' => '非法的表名']);
    exit();
}

$idField = $tableMap[$table]; // 获取对应的主键字段

try {
    // 安全删除 SQL
    $sql = "DELETE FROM `$table` WHERE `$idField` = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    // 执行删除操作
    if ($stmt->execute()) {
        logDebug("Record deleted successfully: Table: $table, ID: $id");
        echo json_encode(['status' => 'success', 'message' => '删除成功']);
    } else {
        logDebug("Failed to delete record: Table: $table, ID: $id");
        echo json_encode(['status' => 'error', 'message' => '删除失败']);
    }
} catch (PDOException $e) {
    logDebug("Database Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => '数据库错误: ' . $e->getMessage()]);
} catch (Exception $e) {
    logDebug("General Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
