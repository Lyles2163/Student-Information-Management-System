<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once 'config.php';

try {
    // 获取 URL 参数中的 id
    $id = $_GET['id'];

    // 获取前端传递的用户数据
    $data = json_decode(file_get_contents("php://input"), true);

    // 更新数据
    $sql = "UPDATE user SET username = ?, avatarUrl = ?, userAccount = ?, userPassword = ?, gender = ?, age = ?, userRole = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $data['username'],
        $data['avatarUrl'],
        $data['userAccount'],
        $data['userPassword'],
        $data['gender'],
        $data['age'],
        $data['userRole'],
        $id
    ]);

    echo json_encode([
        "code" => 200,
        "msg" => "用户信息更新成功"
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "code" => 500,
        "msg" => "数据库操作失败：" . $e->getMessage()
    ]);
}
?>
