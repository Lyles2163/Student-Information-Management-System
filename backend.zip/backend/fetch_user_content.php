<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

try {
    $config = require 'config.php';
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 获取传入的 userId 参数
    $userId = isset($_GET['userId']) ? $_GET['userId'] : null;
    if (!$userId) {
        echo json_encode(['message' => 'User ID is required']);
        exit;
    }

    // 查询用户的动态
    $sql_dynamic = "SELECT * FROM user_dynamic WHERE userId = :userId";
    $stmt_dynamic = $pdo->prepare($sql_dynamic);
    $stmt_dynamic->execute(['userId' => $userId]);
    $dynamic = $stmt_dynamic->fetchAll(PDO::FETCH_ASSOC);

    // 查询用户的活动
    $sql_event = "SELECT * FROM user_event WHERE userId = :userId";
    $stmt_event = $pdo->prepare($sql_event);
    $stmt_event->execute(['userId' => $userId]);
    $event = $stmt_event->fetchAll(PDO::FETCH_ASSOC);

    // 查询用户的作业
    $sql_homework = "SELECT * FROM user_homework WHERE userId = :userId";
    $stmt_homework = $pdo->prepare($sql_homework);
    $stmt_homework->execute(['userId' => $userId]);
    $homework = $stmt_homework->fetchAll(PDO::FETCH_ASSOC);

    // 查询用户的通知
    $sql_notification = "SELECT * FROM user_notification WHERE userId = :userId";
    $stmt_notification = $pdo->prepare($sql_notification);
    $stmt_notification->execute(['userId' => $userId]);
    $notification = $stmt_notification->fetchAll(PDO::FETCH_ASSOC);

    $sql_userRole = "SELECT * FROM user WHERE id = :userId";
    $stmt_userRole = $pdo->prepare($sql_userRole);
    $stmt_userRole->execute(['userId' => $userId]);

    // 查询用户角色信息
    $sql_userRole = "SELECT userRole FROM user WHERE id = :userId";
    $stmt_userRole = $pdo->prepare($sql_userRole);
    $stmt_userRole->execute(['userId' => $userId]);
    $userRole = $stmt_userRole->fetch(PDO::FETCH_ASSOC);
    if ($userRole) {
        $userRole = $userRole['userRole'];
    } else {
        $userRole = null;
    }

    // 返回所有结果
    echo json_encode([
        'dynamic' => $dynamic,
        'event' => $event,
        'homework' => $homework,
        'notification' => $notification,
        'userRole' => $userRole
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
