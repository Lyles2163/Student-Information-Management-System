<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
try {
    // 数据库连接配置，指定端口为
    $config = require 'config.php';
    // 设置 PDO 的错误模式为异常模式
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // SQL 查询语句
    $sql = "SELECT * FROM user";

    // 执行查询
    $stmt = $pdo->query($sql);

    // 获取所有数据
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 将结果转为 JSON 格式并返回
    echo json_encode($users);
} catch (PDOException $e) {
    // 捕获连接错误并输出错误信息
    die("Database connection failed: " . $e->getMessage());
}
?>
