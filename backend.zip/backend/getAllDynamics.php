<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    // 数据库连接
    $config = require 'config.php';


    // 获取所有动态，包括 imageUrls
    $stmt = $pdo->prepare("SELECT ud.dynamicId, ud.userId,ud.username, ud.title, ud.content, ud.avatarUrl, ud.createTime, ud.imageUrls
                           FROM user_dynamic ud
                           JOIN user u ON ud.userId = u.id
                           ORDER BY ud.createTime DESC");

    // 执行查询
    $stmt->execute();

    // 获取所有数据
    $userDynamics = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 返回数据，包括 imageUrls
    echo json_encode(["status" => "success", "userDynamics" => $userDynamics]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "数据库错误: " . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "发生了错误: " . $e->getMessage()]);
}
?>
