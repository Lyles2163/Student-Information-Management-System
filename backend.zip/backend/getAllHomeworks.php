<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    // 数据库连接
    $config = require 'config.php';


    // 获取所有作业
    $stmt = $pdo->prepare("SELECT uh.homeworkId, uh.userId,uh.username, uh.title, uh.content, uh.startDate, uh.endDate, uh.createTime, u.avatarUrl ,uh.imageUrls
                           FROM user_homework uh
                           JOIN user u ON uh.userId = u.id
                           ORDER BY uh.createTime DESC");

    // 执行查询
    $stmt->execute();

    // 获取所有数据
    $userHomeworks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 返回数据
    echo json_encode(["status" => "success", "userHomeworks" => $userHomeworks]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "数据库错误: " . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "发生了错误: " . $e->getMessage()]);
}
?>
