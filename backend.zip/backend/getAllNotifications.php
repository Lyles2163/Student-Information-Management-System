<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

try {
    // 数据库连接
    $config = require 'config.php';


    // 获取所有通知
    $stmt = $pdo->prepare("SELECT un.notificationId, un.userId,un.username, un.title, un.content, un.createTime, u.avatarUrl,un.imageUrls
                           FROM user_notification un
                           JOIN user u ON un.userId = u.id
                           ORDER BY un.createTime DESC");

    // 执行查询
    $stmt->execute();

    // 获取所有数据
    $userNotifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 返回数据
    echo json_encode(["status" => "success", "userNotifications" => $userNotifications]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "数据库错误: " . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "发生了错误: " . $e->getMessage()]);
}
?>
