<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
// 如果是预检请求（OPTIONS），直接返回 204 状态码，表示允许跨域请求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204); // 返回状态码 204 No Content
    exit;
}


require_once 'config.php';

try {
    $stmt = $pdo->query("SELECT * FROM chat_message ORDER BY create_time ASC");
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["messages" => $messages]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["error" => "获取消息失败: " . $e->getMessage()]);
}
