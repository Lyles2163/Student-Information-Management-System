<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

try {
    $config = require 'config.php';
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["error" => "Database connection failed: " . $e->getMessage()]);
    exit;
}

// 获取前端传递的参数
$type = $_GET['type'] ?? '';
$table = '';
$idField = '';

// 根据 type 参数映射表名与主键字段名
switch ($type) {
    case 'dynamic':
        $table = 'user_dynamic';
        $idField = 'dynamicId';
        break;
    case 'event':
        $table = 'user_event';
        $idField = 'eventId';
        break;
    case 'homework':
        $table = 'user_homework';
        $idField = 'homeworkId';
        break;
    case 'notification':
        $table = 'user_notification';
        $idField = 'notificationId';
        break;
    default:
        echo json_encode(["error" => "Invalid request type"]);
        exit;
}

try {
    // 查询对应表的数据
    $stmt = $pdo->query("SELECT * FROM $table ORDER BY createTime DESC");
    $data = [];

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // 统一主键字段为 'id'
        $row['id'] = $row[$idField];

        // 移除 startDate 和 endDate 字段（非作业和活动表）
        if ($type !== 'homework' && $type !== 'event') {
            unset($row['startDate']);
            unset($row['endDate']);
        }

        $data[] = $row;
    }

    // 返回 JSON 数据
    echo json_encode($data);
} catch (PDOException $e) {
    echo json_encode(["error" => "Query failed: " . $e->getMessage()]);
    exit;
}
?>
