<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

try {
    // 数据库连接
    $config = require 'config.php';
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["code" => 500, "message" => "数据库连接失败"]);
    exit;
}

// 获取 `userId` 参数
$userId = isset($_GET['userId']) ? intval($_GET['userId']) : 0;

if (!$userId) {
    echo json_encode(["code" => 400, "message" => "用户 ID 缺失"]);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM userinformation WHERE userId = :userId LIMIT 1");
    $stmt->execute([":userId" => $userId]);
    $info = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($info) {
        echo json_encode([
            "code" => 200,
            "data" => $info,
        ]);
    } else {
        echo json_encode(["code" => 404, "message" => "用户信息不存在"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["code" => 500, "message" => "服务器错误", "error" => $e->getMessage()]);
}
