<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
require_once 'controllers/UserController.php';

$controller = new UserController();

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_GET['action'] === 'fetchUsers') {
    $controller->fetchUsers();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
}
?>
