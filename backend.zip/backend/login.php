<?php
session_start(); // 开启会话

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true"); // 允许携带凭据
header("Content-Type: application/json; charset=UTF-8");

try {
    // 数据库连接配置
    $config = require 'config.php';
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["code" => 500, "message" => "数据库连接失败"]);
    exit;
}

// 获取前端传递的 JSON 数据
$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['username']) || !isset($input['password'])) {
    echo json_encode(["code" => 400, "message" => "用户名和密码不能为空"]);
    exit;
}

$username = $input['username'];
$password = $input['password'];

try {
    // 查询用户表
    $stmt = $pdo->prepare("SELECT * FROM user WHERE userAccount = :username AND userPassword = :password LIMIT 1");
    $stmt->execute([
        ":username" => $username,
        ":password" => $password,
    ]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // 登录成功，设置会话变量
        $_SESSION['userId'] = $user['id'];
        $_SESSION['username'] = $user['username'];

        echo json_encode([
            "code" => 200,
            "message" => "登录成功",
            "data" => [
                "id" => $user['id'],
                "username" => $user['username'],
                "avatarUrl" => $user['avatarUrl'],
                "gender" => $user['gender'],
                "userRole" => $user['userRole']
            ]
        ]);
    } else {
        // 用户名或密码错误
        echo json_encode(["code" => 401, "message" => "用户名或密码错误"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["code" => 500, "message" => "服务器错误", "error" => $e->getMessage()]);
}


