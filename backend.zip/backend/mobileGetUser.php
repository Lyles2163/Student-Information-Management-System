<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

require_once 'config.php'; // 引入 PDO 数据库连接配置

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);

    try {
        // 使用 PDO 进行预处理查询
        $stmt = $pdo->prepare("SELECT id, username, age, userAccount, avatarUrl, gender, createTime, userRole 
                               FROM user WHERE id = :id");
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);
        $stmt->execute();

        // 获取查询结果
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            echo json_encode(["code" => 200, "data" => $user]);
        } else {
            echo json_encode(["code" => 404, "message" => "用户不存在"]);
        }
    } catch (PDOException $e) {
        echo json_encode(["code" => 500, "message" => "查询失败", "error" => $e->getMessage()]);
    }
} else {
    echo json_encode(["code" => 400, "message" => "缺少有效的用户ID"]);
}
?>
