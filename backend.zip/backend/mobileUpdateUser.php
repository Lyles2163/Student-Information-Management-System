<?php
// 允许跨域请求的头部
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // 允许所有域名访问
header("Access-Control-Allow-Methods: POST, GET, OPTIONS"); // 允许的请求方法
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

require_once 'config.php'; // 引入数据库配置

// 获取请求体中的数据
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['id'])) {
    $id = intval($data['id']);
    $username = $data['username'];
    $age = intval($data['age']);
    $userAccount = $data['userAccount'];
    $gender = $data['gender'];
    $userPassword = $data['userPassword'];
//    $userPassword = password_hash($data['userPassword'], PASSWORD_BCRYPT); // 密码加密

    try {
        // 使用 PDO 执行更新操作
        $stmt = $pdo->prepare("UPDATE user SET username = ?, age = ?, userAccount = ?, gender = ?, userPassword = ? WHERE id = ?");

        // 执行语句，传入参数
        $stmt->execute([$username, $age, $userAccount, $gender, $userPassword, $id]);

        // 检查是否有行受到影响（即是否成功更新）
        if ($stmt->rowCount() > 0) {
            echo json_encode(["code" => 200, "message" => "更新成功"]);
        } else {
            echo json_encode(["code" => 500, "message" => "更新失败"]);
        }
    } catch (PDOException $e) {
        // 捕获异常并返回错误信息
        echo json_encode(["code" => 500, "message" => "数据库错误: " . $e->getMessage()]);
    }
} else {
    // 如果缺少必要的参数，返回错误信息
    echo json_encode(["code" => 400, "message" => "缺少必要参数"]);
}
?>
