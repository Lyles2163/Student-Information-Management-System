<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true'); // 允许携带 cookie

// 处理 OPTIONS 请求（CORS 预检请求）
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 引入数据库连接配置文件
include 'config.php';

// 获取前端传递的数据
$data = json_decode(file_get_contents('php://input'), true);
$userAccount = $data['userAccount'] ?? '';
$password = $data['registerPassword'] ?? '';
$confirmPassword = $data['confirmPassword'] ?? '';
$phone = $data['phone'] ?? '';
$code = $data['code'] ?? ''; // 获取前端传递的验证码

// 校验必填项
if (empty($userAccount) || empty($password) || empty($confirmPassword) || empty($phone) || empty($code)) {
    echo json_encode(["status" => "error", "message" => "请输入所有字段"]);
    exit();
}

// 验证验证码
$sql = "SELECT code, expiry_time FROM sms_verification WHERE phone = ? ORDER BY created_at DESC LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute([$phone]);
$record = $stmt->fetch();

if (!$record || $record['code'] !== $code || strtotime($record['expiry_time']) < time()) {
    echo json_encode(["status" => "error", "message" => "验证码错误或已过期"]);
    exit();
}

// 检查密码和确认密码是否一致
if ($password !== $confirmPassword) {
    echo json_encode(["status" => "error", "message" => "密码和确认密码不一致"]);
    exit();
}

// 检查用户账号是否已存在
$sql = "SELECT id FROM user WHERE userAccount = :userAccount";
$stmt = $pdo->prepare($sql);
$stmt->execute(['userAccount' => $userAccount]);
if ($stmt->rowCount() > 0) {
    echo json_encode(["status" => "error", "message" => "用户账号已存在"]);
    exit();
}

// 默认数据
$age = 20;
$avatarUrl = 'assets/media/classImg/test女.jpg'; // 默认头像URL
$gender = '男'; // 默认性别
$userRole = 0; // 默认用户角色

// 插入用户数据（密码直接保存，不加密）
$sql = "INSERT INTO user (username, age, userAccount, avatarUrl, gender, userPassword, userRole) 
        VALUES (:username, :age, :userAccount, :avatarUrl, :gender, :userPassword, :userRole)";
$stmt = $pdo->prepare($sql);

$params = [
    'username' => 'user' . rand(100000, 999999), // 自动生成用户名 (user + 随机6位数字)
    'age' => $age,
    'userAccount' => $userAccount,
    'avatarUrl' => $avatarUrl,
    'gender' => $gender,
    'userPassword' => $password, // 直接保存密码
    'userRole' => $userRole
];

// 执行插入
if ($stmt->execute($params)) {
    // 删除已使用的验证码，防止重复使用
    $pdo->prepare("DELETE FROM sms_verification WHERE phone = ?")->execute([$phone]);

    echo json_encode(["status" => "success", "message" => "注册成功"]);
} else {
    echo json_encode(["status" => "error", "message" => "注册失败，请稍后重试"]);
}
?>
