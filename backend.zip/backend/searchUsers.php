<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once 'config.php';  // 引入数据库配置

try {
    // 获取查询的用户名
    $username = isset($_GET['username']) ? $_GET['username'] : '';

    // 如果没有提供用户名，返回空数组
    if (!$username) {
        echo json_encode([
            "code" => 400,
            "msg" => "用户名未提供",
            "usersData" => []
        ]);
        exit;
    }

    // SQL 查询语句，根据用户名进行模糊查询
    $sql = "SELECT * FROM user WHERE username LIKE :username";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['username' => "%$username%"]);

    // 获取查询结果
    $usersData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 返回成功响应
    echo json_encode([
        "code" => 200,
        "msg" => "搜索成功",
        "usersData" => $usersData
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "code" => 500,
        "msg" => "数据库连接失败：" . $e->getMessage(),
        "usersData" => []
    ]);
}
?>
