<?php
// 允许跨域请求的头部
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // 允许所有域名访问
header("Access-Control-Allow-Methods: POST, GET, OPTIONS"); // 允许的请求方法
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

// 处理预检请求 (OPTIONS 请求)，直接返回204状态码
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204); // 返回状态码 204 No Content
    exit;
}

require_once 'config.php'; // 引入数据库配置

// 获取请求的 JSON 数据
$data = json_decode(file_get_contents("php://input"), true);

// 参数校验，确保请求中包含 sender_id 和 message
if (!isset($data['sender_id'], $data['message'])) {
    http_response_code(400); // 请求错误
    echo json_encode(["error" => "参数不完整"]);
    exit;
}

$senderId = $data['sender_id'];
$message = trim($data['message']);

// 获取用户信息
try {
    $stmtUser = $pdo->prepare("SELECT username, avatarUrl FROM user WHERE id = :sender_id");
    $stmtUser->execute([':sender_id' => $senderId]);
    $user = $stmtUser->fetch();

    if (!$user) {
        http_response_code(404); // 用户未找到
        echo json_encode(["error" => "用户不存在"]);
        exit;
    }

    $username = $user['username'];
    $avatarUrl = $user['avatarUrl'];

    // 插入消息到数据库
    $stmtInsert = $pdo->prepare("
        INSERT INTO chat_message (sender_id, username, avatarUrl, message)
        VALUES (:sender_id, :username, :avatarUrl, :message)
    ");
    $stmtInsert->execute([
        ':sender_id' => $senderId,
        ':username' => $username,
        ':avatarUrl' => $avatarUrl,
        ':message' => $message,
    ]);

    echo json_encode([
        "status" => "success",
        "message" => "消息发送成功"
    ]);
} catch (PDOException $e) {
    // 数据库错误处理
    http_response_code(500); // 服务器内部错误
    echo json_encode(["error" => "数据库错误: " . $e->getMessage()]);
}
?>
