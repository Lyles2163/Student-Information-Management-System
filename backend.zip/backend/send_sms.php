<?php
header("Content-Type: application/json; charset=UTF-8");
// 允许跨域请求
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header('Access-Control-Allow-Credentials: true'); // 允许携带 cookie

include 'config.php';  

// 获取前端传来的手机号
$data = json_decode(file_get_contents("php://input"), true);
$phone = $data['phone'] ?? null;

if (!$phone || !preg_match("/^1[3-9]\d{9}$/", $phone)) {
    echo json_encode(["status" => "error", "message" => "请输入正确的手机号"]);
    exit();
}

// 生成验证码
$code = rand(1000, 9999);
$expiry_time = date("Y-m-d H:i:s", time() + 300); // 5分钟有效

// 删除已存在的验证码记录，防止同一个手机号重复存储
$pdo->prepare("DELETE FROM sms_verification WHERE phone = ?")->execute([$phone]);

// 将验证码存入数据库
$stmt = $pdo->prepare("INSERT INTO sms_verification (phone, code, expiry_time) VALUES (?, ?, ?)");
if ($stmt->execute([$phone, $code, $expiry_time])) {
    // 发送短信接口参数
    $apiUrl = "http://106.ihuyi.com/webservice/sms.php?method=Submit";
    $apiAccount = "C11324729";  // 短信平台账号
    $apiPassword = "dd0a3f05ca34f6246022e74c3c5838ce";
    $content = "您的验证码是{$code}，请勿泄露。";

    // 请求短信接口
    $requestUrl = "{$apiUrl}&account={$apiAccount}&password={$apiPassword}&mobile={$phone}&content=" . urlencode($content);

    $response = file_get_contents($requestUrl);

    if ($response) {
        echo json_encode(["status" => "success", "message" => "验证码已发送"]);
    } else {
        echo json_encode(["status" => "error", "message" => "验证码发送失败"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "验证码保存失败"]);
}
?>
