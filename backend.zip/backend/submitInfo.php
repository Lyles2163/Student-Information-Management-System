<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

try {
    // 数据库连接
    $config = require 'config.php';
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 获取请求的内容
    $data = json_decode(file_get_contents("php://input"), true);

    // 必要的字段检查
    if (!isset($data['userId'], $data['title'], $data['username'],$data['content'], $data['type'])) {
        echo json_encode(["status" => "error", "message" => "缺少必要的字段"]);
        exit;
    }

    // 设置基本的数据
    $userId = $data['userId'];
    $title = $data['title'];
    $username = $data['username'];
    $content = $data['content'];
    $avatarUrl = $data['avatarUrl'] ?? null;
    $type = $data['type']; // 动态、活动、作业、通知
    $startDate = $data['startDate'] ?? null;
    $endDate = $data['endDate'] ?? null;
    $images = $data['images'] ?? [];

    // 获取上传图片路径
    $imageUrls = [];
    if (!empty($images)) {
        $imageUrls = $images; // 如果是从上传接口传来的路径数组，直接使用
    }

    // 根据不同类型插入不同的表
    if ($type == "动态") {
        $stmt = $pdo->prepare("INSERT INTO user_dynamic (userId, title, username, content, avatarUrl, imageUrls) VALUES (?, ?,?, ?, ?, ?)");
        $stmt->execute([$userId, $title,$username, $content, $avatarUrl, json_encode($imageUrls)]);
    } elseif ($type == "活动") {
        if (!$startDate || !$endDate) {
            echo json_encode(["status" => "error", "message" => "缺少开始日期或结束日期"]);
            exit;
        }
        $stmt = $pdo->prepare("INSERT INTO user_event (userId, title, username, content, avatarUrl, startDate, endDate, imageUrls) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $title,$username, $content, $avatarUrl, $startDate, $endDate, json_encode($imageUrls)]);
    } elseif ($type == "作业") {
        if (!$startDate || !$endDate) {
            echo json_encode(["status" => "error", "message" => "缺少开始日期或结束日期"]);
            exit;
        }
        $stmt = $pdo->prepare("INSERT INTO user_homework (userId, title, username, content, avatarUrl, startDate, endDate, imageUrls) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $title,$username, $content, $avatarUrl, $startDate, $endDate, json_encode($imageUrls)]);
    } elseif ($type == "通知") {
        $stmt = $pdo->prepare("INSERT INTO user_notification (userId, title, username, content, avatarUrl, imageUrls) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $title,$username, $content, $avatarUrl, json_encode($imageUrls)]);
    } else {
        echo json_encode(["status" => "error", "message" => "无效的发布类型"]);
        exit;
    }

    echo json_encode(["status" => "success", "message" => "信息已成功提交"]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "数据库错误: " . $e->getMessage()]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "发生了错误: " . $e->getMessage()]);
}
?>
