<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header('Access-Control-Allow-Headers: Content-Type, Authorization');
// 处理预检请求（OPTIONS 请求）
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
try {
    require_once 'config.php'; // 引入数据库配置
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => '数据库连接失败: ' . $e->getMessage()]);
    exit();
}

// 验证传入数据
$table = $_POST['table'] ?? '';
$id = $_POST['id'] ?? null;
$title = $_POST['title'] ?? '';
$content = $_POST['content'] ?? '';
$startDate = $_POST['startDate'] ?? null;
$endDate = $_POST['endDate'] ?? null;

// 检查表名是否合法
if (!in_array($table, $tableMap)) {
    echo json_encode(['status' => 'error', 'message' => '非法的表名']);
    exit();
}

// 上传文件处理
$uploadedFilePath = null;
if (!empty($_FILES['image']) && $_FILES['image']['error'] == 0) {
    $uploadDir = __DIR__ . '/uploads/'; // 图片上传目录
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    $fileName = time() . '_' . basename($_FILES['image']['name']);
    $uploadedFilePath = $uploadDir . $fileName;

    if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadedFilePath)) {
        echo json_encode(['status' => 'error', 'message' => '文件上传失败']);
        exit();
    }

    // 保存文件路径（相对路径，存储到数据库）
    $uploadedFilePath = 'uploads/' . $fileName;
}

// 构建 SQL 更新语句
try {
    // 基本字段
    $fields = [
        'title' => $title,
        'content' => $content,
    ];

    if ($startDate) $fields['startDate'] = $startDate;
    if ($endDate) $fields['endDate'] = $endDate;
    if ($uploadedFilePath) $fields['imageUrls'] = json_encode([$uploadedFilePath]); // 假设存储 JSON 格式

    // 动态拼接 SQL SET 语句
    $setClause = implode(', ', array_map(fn($key) => "$key = :$key", array_keys($fields)));

    // 主键 ID 字段根据表动态变化
    $idField = $table . 'Id';

    $sql = "UPDATE $table SET $setClause WHERE $idField = :id";

    $stmt = $pdo->prepare($sql);
    foreach ($fields as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    $stmt->bindValue(':id', $id);

    // 执行 SQL
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => '更新成功']);
    } else {
        echo json_encode(['status' => 'error', 'message' => '更新失败']);
    }
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => '数据库错误: ' . $e->getMessage()]);
}
?>