<?php
session_start(); // 开启会话

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

try {
    // 数据库连接配置
    $config = require 'config.php';
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["code" => 500, "message" => "数据库连接失败"]);
    exit;
}

// 获取前端传递的 JSON 数据
$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['userID'])) {
    echo json_encode(["code" => 400, "message" => "缺少必要参数：userID"]);
    exit;
}

$userID = $input['userID'];
$slogan = $input['slogan'] ?? null;
$jobTitle = $input['jobTitle'] ?? null;
$company = $input['company'] ?? null;
$location = $input['location'] ?? null;
$dreamGoal = $input['dreamGoal'] ?? null;

try {
    // 检查用户信息是否已存在
    $stmt = $pdo->prepare("SELECT id FROM userinformation WHERE userId = :userID");
    $stmt->execute([":userID" => $userID]);
    $existingRecord = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingRecord) {
        // 更新已有的用户信息
        $updateStmt = $pdo->prepare("
            UPDATE userinformation 
            SET slogan = :slogan, jobTitle = :jobTitle, company = :company, location = :location, dreamGoal = :dreamGoal 
            WHERE userId = :userID
        ");
        $updateStmt->execute([
            ":slogan" => $slogan,
            ":jobTitle" => $jobTitle,
            ":company" => $company,
            ":location" => $location,
            ":dreamGoal" => $dreamGoal,
            ":userID" => $userID
        ]);

        echo json_encode(["code" => 200, "message" => "个人信息更新成功"]);
    } else {
        // 插入新的用户信息
        $insertStmt = $pdo->prepare("
            INSERT INTO userinformation (userId, slogan, jobTitle, company, location, dreamGoal) 
            VALUES (:userID, :slogan, :jobTitle, :company, :location, :dreamGoal)
        ");
        $insertStmt->execute([
            ":userID" => $userID,
            ":slogan" => $slogan,
            ":jobTitle" => $jobTitle,
            ":company" => $company,
            ":location" => $location,
            ":dreamGoal" => $dreamGoal
        ]);

        echo json_encode(["code" => 200, "message" => "个人信息保存成功"]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["code" => 500, "message" => "服务器错误", "error" => $e->getMessage()]);
}
