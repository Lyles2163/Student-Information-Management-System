<?php
// 允许跨域请求
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// 处理预检请求
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

$uploadDir = 'uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$uploadedUrls = [];

// 检查是否有文件上传
if (isset($_FILES['file']) && is_array($_FILES['file']['name'])) {
    foreach ($_FILES['file']['name'] as $index => $fileName) {
        $fileTmpName = $_FILES['file']['tmp_name'][$index];
        $fileSize = $_FILES['file']['size'][$index];
        $fileType = mime_content_type($fileTmpName);

        $uploadPath = $uploadDir . basename($fileName);

        // 允许的文件类型
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg'];
        if (!in_array($fileType, $allowedTypes)) {
            echo json_encode(["status" => "error", "message" => "只能上传图片文件！"]);
            http_response_code(400);
            exit;
        }

        if (move_uploaded_file($fileTmpName, $uploadPath)) {
            $uploadedUrls[] = 'http://localhost/backend/' . $uploadPath;
        } else {
            echo json_encode(["status" => "error", "message" => "文件上传失败"]);
            http_response_code(500);
            exit;
        }
    }

    echo json_encode(["status" => "success", "message" => "文件上传成功", "urls" => $uploadedUrls]);
} else {
    echo json_encode(["status" => "error", "message" => "没有文件上传"]);
    http_response_code(400);
}
?>
