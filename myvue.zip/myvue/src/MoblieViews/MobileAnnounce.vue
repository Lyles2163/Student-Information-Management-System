<template>
  <div class="publish-center">
    <!-- 顶部标题栏 -->
    <a-page-header title="发布中心" @back="() => $router.back()" class="page-header" />
    <div v-if="loading" class="global-loading" style="display: flex; flex-direction: column ;">
      <img src="/assets/media/loading9.gif" alt="Loading..." class="custom-loading-gif" style="width: 200px;height:200px" />
      <p class="loading-text" style="color: #fefefe; font-size: 20px;text-shadow: 0 2px 20px black">加载中...</p>
    </div>

    <!-- 按钮区域 -->
    <div class="content">
      <a-button type="primary" block class="action-button dynamic"  @click="openDrawer('动态')">
        发布动态
      </a-button>
      <a-button type="primary" block class="action-button event"  @click="openDrawer('活动')">
        发布活动
      </a-button>
      <a-button type="primary" block class="action-button homework"  @click="openDrawer('作业')">
        发布作业
      </a-button>
      <a-button type="primary" block class="action-button notification"  @click="openDrawer('通知')">
        发布通知
      </a-button>
    </div>

    <!-- 抽屉 -->
    <a-drawer
        :visible="drawerVisible"
        :title="drawerTitle"
        placement="right"
        @close="drawerVisible = false"
        width="100%"
    >
      <div>
        <!-- 标题输入 -->
        <p class="input-label">标题</p>
        <a-input v-model:value="formData.title" placeholder="请输入标题" class="drawer-input" />

        <!-- 内容输入 -->
        <p class="input-label">内容</p>
        <a-textarea
            v-model:value="formData.content"
            rows="4"
            placeholder="请输入内容..."
            class="drawer-textarea"
        />

        <!-- 日期选择，仅活动和作业显示 -->
        <div v-if="currentType === '活动' || currentType === '作业'" class="date-picker-section">
          <p class="input-label">开始日期</p>
          <a-date-picker
              v-model:value="formData.startDate"
              placeholder="请选择开始日期"
              style="width: 100%;"
          />
          <p class="input-label" style="margin-top: 15px;">结束日期</p>
          <a-date-picker
              v-model:value="formData.endDate"
              placeholder="请选择结束日期"
              style="width: 100%;"
          />
        </div>

        <!-- 图片上传 -->
        <p class="input-label">上传图片</p>
        <input type="file" @change="handleFileChange" multiple />

        <!-- 提交按钮 -->
        <a-button type="primary" block style="margin-top: 20px;" @click="submitContent">
          提交
        </a-button>
      </div>
    </a-drawer>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { message } from "ant-design-vue";

// 抽屉相关状态
const drawerVisible = ref(false);
const drawerTitle = ref("");
const currentType = ref(""); // 区分 "活动" 和 "作业" 以显示日期选择框
const loading = ref(false); // 控制全局 Loading 弹窗的状态

// 表单数据
const formData = ref({
  title: "",
  content: "",
  username:"",
  images: [], // 图片列表，包含文件URL
  startDate: null,
  endDate: null,
});

// 打开抽屉（增加全局 loading）
const openDrawer = (type) => {
  loading.value = true; // 显示 Loading 弹窗
  setTimeout(() => {
    drawerTitle.value = `发布${type}`;
    currentType.value = type; // 保存当前类型
    drawerVisible.value = true; // 打开抽屉
    loading.value = false; // 隐藏 Loading 弹窗
  }, 1100); // 延迟
};

// 提交内容
const submitContent = async () => {
  if (!formData.value.title.trim()) {
    message.warning("请输入标题后再提交！");
    return;
  }
  if (!formData.value.content.trim()) {
    message.warning("请输入内容后再提交！");
    return;
  }

  // 对活动和作业进行日期校验
  if (
      (currentType.value === "活动" || currentType.value === "作业") &&
      (!formData.value.startDate || !formData.value.endDate)
  ) {
    message.warning("请选择开始日期和结束日期！");
    return;
  }

  // 准备提交的数据
  const requestData = {
    userId: localStorage.getItem("userID"), // 用户ID
    title: formData.value.title,
    username: localStorage.getItem("currentUsername"),
    content: formData.value.content,
    avatarUrl: localStorage.getItem("avatarUrl"), // 头像URL
    type: currentType.value, // 类型（动态、活动、作业、通知）
    startDate: formData.value.startDate || null,
    endDate: formData.value.endDate || null,
    images: formData.value.images, // 直接保存图片路径
  };

  try {
    const response = await fetch("http://localhost/backend/submitInfo.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestData),
    });

    const result = await response.json();
    if (result.status === "success") {
      message.success("信息已成功提交！");
      drawerVisible.value = false; // 关闭抽屉
      formData.value = { title: "", content: "", images: [], startDate: null, endDate: null }; // 清空表单
    } else {
      message.error(result.message);
    }
  } catch (error) {
    message.error("提交失败，请重试！");
    console.error(error);
  }
};

// 处理文件上传
const handleFileChange = async (event) => {
  const files = event.target.files;
  if (files.length === 0) {
    return;
  }

  // 将文件转换为 FormData 对象并上传
  const formDataObj = new FormData();
  Array.from(files).forEach((file) => {
    formDataObj.append("file[]", file); // 确保字段名与后端一致
  });

  try {
    const uploadResponse = await fetch("http://localhost/backend/upload.php", {
      method: "POST",
      body: formDataObj,
    });
    const result = await uploadResponse.json();

    if (result.status === "success") {
      // 将上传的图片URL保存到表单中
      formData.value.images = formData.value.images.concat(result.urls);
    } else {
      message.error(result.message);
    }
  } catch (error) {
    message.error("上传图片失败！");
    console.error(error);
  }
};
</script>



<style scoped>
.global-loading {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.19); /* 半透明背景 */
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999; /* 确保 Loading 在最上层 */
}

.publish-center {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: #f5f5f5;
}

.page-header {
  background-color: #1d92ff;
  color: white;
}

.content {
  flex: 1;
  padding: 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  gap: 15px;
}

.action-button {
  box-shadow: 10px 5px 20px rgba(0, 0, 0, 0.3);
  font-size: 30px;
  letter-spacing: 20px;
  height: 150px;
transform: translateY(-5vh);
  padding-bottom: 10px;
  border-radius: 6px;
  transition: all 0.3s ease;
}
.action-button:hover {
  box-shadow: -5px -10px 16px rgba(0, 0, 0, 0.3);
  transform: translateY(-6vh) scale(0.96);
  filter: brightness(1.1);
  cursor: pointer;
}
.dynamic {
  background: linear-gradient(90deg, #9d34ff, #3fffe1);
  border: none;
  color: white;
}

.event {
  background: linear-gradient(90deg, #ffa634, #ff0a24);
  border: none;
  color: white;
}

.homework {
  background: linear-gradient(90deg, #34ff7b, #0ab1ee);
  border: none;
  color: white;
}

.notification {
  background: linear-gradient(90deg, #f8ff34, #e514fd);
  border: none;
  color: white;
}

.input-label {
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 5px;
}

.drawer-input {
  width: 100%;
  margin-bottom: 20px;
}

.drawer-textarea {
  width: 100%;
  resize: none;
  margin-bottom: 20px;
}

.date-picker-section {
  margin-bottom: 20px;
}
</style>
