<template>
  <div class="contact-list">
    <!-- 头部部分 -->
    <div class="header">
      <h1>2305班</h1>
    </div>
    <!-- 用户列表 -->
    <div v-for="user in users" :key="user.id" class="contact-item">
      <a-avatar shape="square" :size="64" :src="user.avatarUrl" alt="Avatar" class="avatar" />
      <div class="contact-info">
        <p class="user-name">{{ user.username }}</p>
      </div>
      <a-button @click="openDrawer(user)" class="drawer-button">></a-button>
    </div>
    <!-- 外层抽屉：展示用户发布内容的标题 -->
    <a-drawer v-model:open="drawerVisible" title="用户发布内容" :width="400" @update:open="closeDrawer">
      <p><strong>用户名:</strong> {{ selectedUser.username }}</p>
      <p><strong>头像:</strong> <a-avatar shape="square" :src="selectedUser.avatarUrl" alt="Avatar" class="avatar" /></p>
      <h3>发布内容</h3>
      <!-- 动态、活动、作业、通知的标题 -->
      <div v-if="userContent">
        <div v-if="userContent.dynamic.length">
          <h4>动态</h4>
          <ul>
            <li v-for="item in userContent.dynamic" :key="item.dynamicId">
              <a-button @click="openNestedDrawer('dynamic', item); typeDynamic()" size="small">{{ item.title }}</a-button>
            </li>
          </ul>
        </div>
        <div v-if="userContent.event.length">
          <h4>活动</h4>
          <ul>
            <li v-for="item in userContent.event" :key="item.eventId">
              <a-button @click="openNestedDrawer('event', item); typeEvent()" size="small">{{ item.title }}</a-button>
            </li>
          </ul>
        </div>
        <div v-if="userContent.homework.length">
          <h4>作业</h4>
          <ul>
            <li v-for="item in userContent.homework" :key="item.homeworkId">
              <a-button @click="openNestedDrawer('homework', item); typeHomework()" size="small">{{ item.title }}</a-button>
            </li>
          </ul>
        </div>
        <div v-if="userContent.notification.length">
          <h4>通知</h4>
          <ul>
            <li v-for="item in userContent.notification" :key="item.notificationId">
              <a-button @click="openNestedDrawer('notification', item); typeNotification()" size="small">{{ item.title }}</a-button>
            </li>
          </ul>
        </div>
      </div>
      <p v-else>暂无发布内容</p>
    </a-drawer>
    <!-- 内层嵌套抽屉：展示发布内容的详细信息 -->
    <a-drawer v-model:open="nestedDrawerVisible" title="发布详情" :width="400" @update:open="closeNestedDrawer"
              style="border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15); background-color: #fff;">
      <div v-if="nestedContent" style="padding: 20px;">
        <!-- 用户头像和标题部分 -->
        <a-row align="middle" :gutter="16" class="nested-drawer-header" style="margin-bottom: 20px;">
          <a-col :span="4">
            <a-avatar shape="square" :size="64" :src="nestedContent.avatarUrl" alt="Avatar" class="nested-avatar"
                      style="border-radius: 4px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);" />
          </a-col>
          <a-col :span="20">
            <div style="display: flex; flex-direction: column;">
              <p style="color: #838383; font-size: 12px; margin-bottom: 5px;margin-left: 50px;">{{nestedContent.createTime}}</p>
              <h1 style="color: #060606; font-size: 18px; font-weight: 500;margin-left: 50px;">{{ nestedContent.username }}</h1>
              <!-- 根据不同用户角色渲染对应标签 -->
              <div v-if="Number(nestedContent.userRole) === 1">
                <a-tag color="red">管理员</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 2">
                <a-tag color="orange">VIP用户</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 0">
                <a-tag color="blue">普通用户</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 3">
                <a-tag color="maroon">双创委员</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 4">
                <a-tag color="gold">伍班班长</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 5">
                <a-tag color="green">学习委员</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 6">
                <a-tag color="">副班长</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 7">
                <a-tag color="yellow">宣传委员</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 8">
                <a-tag color="gold">团支书</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 9">
                <a-tag color="gold">副团支书</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 10">
                <a-tag color="gold">体育委员</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 11">
                <a-tag color="gold">组织委员</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 12">
                <a-tag color="gold">劳动委员</a-tag>
              </div>
              <div v-if="Number(nestedContent.userRole) === 13">
                <a-tag color="gold">心理委员</a-tag>
              </div>
            </div>
          </a-col>
        </a-row>
        <!-- 内容展示 -->
        <div style="margin-bottom: 20px;">
          <h3 style="color: #333; font-size: 16px; margin-bottom: 10px;">{{ nestedContent.title }}</h3>
          <p style="color: #555; font-size: 14px; line-height: 1.6;"><strong>内容:</strong> {{ nestedContent.content }}</p>
        </div>
        <!-- 图片展示 -->
        <div v-if="nestedContent.imageUrls" style="margin-bottom: 20px;">
          <p style="color: #555; font-size: 14px; margin-bottom: 10px;"><strong>图片:</strong></p>
          <div style="display: flex; flex-wrap: wrap;">
            <div v-for="(image, index) in JSON.parse(nestedContent.imageUrls)" :key="index"
                 style="width: 120px; height: 120px; margin-right: 10px; margin-bottom: 10px;">
              <a-image :src="image" :width="120" :height="120" alt="Image" class="nested-image"
                       style="border-radius: 4px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); width: 100%; height: 100%; object-fit: cover;" />
            </div>
          </div>
        </div>
        <!-- 评论区 -->
        <div style="margin-bottom: 20px;">
          <textarea v-model="commentText" class="comment-textarea" placeholder="添加评论..."
                    style="width: 100%; height: 80px; padding: 8px; font-size: 14px; border: 1px solid #d9d9d9; border-radius: 4px; resize: none; margin-bottom: 10px;"></textarea>
          <a-button @click="submitComment" class="comment-submit-btn" style="background: green; color: white; padding: 6px 12px; border: none; border-radius: 4px; cursor: pointer;">提交评论</a-button>
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 20px;">
          <a-button @click="zanhandleClick" icon="👍" class="zan-button"
                    style="padding: 6px 12px; background-color: #f0f0f0; border: none; border-radius: 4px; cursor: pointer;">点赞</a-button>
        </div>
        <div v-if="nestedContent.comments" style="margin-bottom: 20px;">
          <h4 style="color: #333; font-size: 16px; margin-bottom: 10px;">评论区</h4>
          <ul style="list-style: none; padding: 0;">
            <li v-for="(comment, index) in nestedContent.comments" :key="index"
                style="display: flex; align-items: flex-start; margin-bottom: 15px;">
              <a-avatar shape="square" :src="comment.avatarUrl" alt="Avatar"
                        style="width: 32px; height: 32px; border-radius: 4px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); margin-right: 10px;" />
              <div style="display: flex; flex-direction: column;">
                <span style="color: #717171;font-size: 10px;">{{comment.time}}</span>
                <p style="color: #333; font-size: 14px;">{{ comment.username }}: {{ comment.content }}</p>
              </div>
            </li>
          </ul>
        </div>
        <!-- 如果缓存中没有评论数据，则显示暂无评论，并添加一个提示信息，告知用户可以添加评论 -->
        <p v-else style="text-align: center; color: #aaa; font-size: 14px;">暂无评论，点击输入框可添加评论哦~</p>
        <!-- 点赞功能 -->
      </div>
    </a-drawer>
  </div>
</template>

<script setup>
import { ref, onMounted, reactive } from 'vue';
import confetti from "canvas-confetti";
import { message } from 'ant-design-vue';

const users = ref([]); // 用户列表数据，初始为空数组
const drawerVisible = ref(false); // 外层抽屉的显示状态，初始为关闭
const nestedDrawerVisible = ref(false); // 内层嵌套抽屉的显示状态，初始为关闭
const selectedUser = ref(null); // 当前选中的用户对象
const userContent = ref({
  dynamic: [],
  event: [],
  homework: [],
  notification: [],
}); // 用于存储当前选中用户的各类发布内容，初始结构为包含对应属性的对象，属性值为空数组
const nestedContent = ref(null); // 当前展示详细信息的发布内容对象
const commentText = ref(""); // 用于绑定评论输入框中的文本内容

// 分别新增ref用于存储不同类型的Id，初始值设为null，根据实际情况调整
const dynamicIdRef = ref(null);
const eventIdRef = ref(null);
const homeworkIdRef = ref(null);
const notificationIdRef = ref(null);

// 获取用户列表
onMounted(async () => {
  try {
    const response = await fetch('http://localhost/backend/fetch_users.php');
    const data = await response.json();
    users.value = data;
  } catch (error) {
    console.error('获取用户数据失败:', error);
  }
});

// 打开外层抽屉并设置选中的用户，同时获取该用户的发布内容
const openDrawer = async (user) => {
  selectedUser.value = user;
  drawerVisible.value = true;
  try {
    const response = await fetch(`http://localhost/backend/fetch_user_content.php?userId=${user.id}`);
    const data = await response.json();
    // 根据后端返回的数据结构，正确解析并赋值给 userContent.value
    // 这里做更严谨的数据处理，确保即便后端返回部分数据缺失，对应属性也能初始化为空数组
    userContent.value = {
      dynamic: Array.isArray(data.dynamic)? data.dynamic : [],
      event: Array.isArray(data.event)? data.event : [],
      homework: Array.isArray(data.homework)? data.homework : [],
      notification: Array.isArray(data.notification)? data.notification : [],
      userRole: data.userRole || null
    };

  } catch (error) {
    console.error('获取用户内容失败:', error);
    // 如果获取失败，将 userContent.value 的各属性重置为空数组，避免出现数据异常情况
    userContent.value = {
      dynamic: [],
      event: [],
      homework: [],
      notification: [],
      userRole: null
    };
  }
};
// 关闭外层抽屉
const closeDrawer = (open) => {
  drawerVisible.value = open;
};

// 打开内层嵌套抽屉并设置发布内容的详细信息，同时从浏览器缓存中加载该发布内容对应的评论数据
const openNestedDrawer = (type, item) => {
  nestedContent.value = item;
  // 根据不同类型，将对应的Id赋值给相应的ref变量
  if (type === 'dynamic') {
    dynamicIdRef.value = item.dynamicId;
  } else if (type === 'event') {
    eventIdRef.value = item.eventId;
  } else if (type === 'homework') {
    homeworkIdRef.value = item.homeworkId;
  } else if (type === 'notification') {
    notificationIdRef.value = item.notificationId;
  }
  const fetchCommentsForContent = () => {
    let storageKey = '';
    if (type === 'dynamic') {
      storageKey = `comments_${dynamicIdRef.value}`;
    } else if (type === 'event') {
      storageKey = `comments_${eventIdRef.value}`;
    } else if (type === 'homework') {
      storageKey = `comments_${homeworkIdRef.value}`;
    } else if (type === 'notification') {
      storageKey = `comments_${notificationIdRef.value}`;
    }
    const storedComments = localStorage.getItem(storageKey);
    if (storedComments) {
      try {
        nestedContent.value.comments = JSON.parse(storedComments);
      } catch (error) {
        console.error(`解析缓存的评论数据（${storageKey}）出错`, error);
        localStorage.removeItem(storageKey);
        nestedContent.value.comments = [];
      }
    } else {
      nestedContent.value.comments = [];
    }
  };
  fetchCommentsForContent();
  nestedDrawerVisible.value = true;
};

const typeNotification = () => {
  nestedContent.type = 'notification';
  console.log(nestedContent.type);
}
const typeDynamic = () => {
  nestedContent.type = 'dynamic';
  console.log(nestedContent.type);
}
const typeEvent = () => {
  nestedContent.type = 'event';
  console.log(nestedContent.type);
}
const typeHomework = () => {
  nestedContent.type = 'homework';
  console.log(nestedContent.type);
}
// 关闭内层嵌套抽屉
const closeNestedDrawer = (open) => {
  nestedDrawerVisible.value = open;
};

// 提交评论
const submitComment = () => {
  const comment = commentText.value.trim();
  if (comment) {
    const now = new Date();
    const commentTime = now.toLocaleString();
    const newComment = {
      content: comment,
      avatarUrl: localStorage.getItem("avatarUrl") || "",
      username: localStorage.getItem("currentUsername") || "匿名用户",
      time: commentTime,
    };
    if (!nestedContent.value.comments) {
      nestedContent.value.comments = [];
    }
    nestedContent.value.comments.push(newComment);
    // 保存评论到本地存储（浏览器缓存），使用 comments_${content.eventId} 作为存储键名
    try {
      let storageKey = '';
      if (nestedContent.type === 'dynamic') {
        storageKey = `comments_${dynamicIdRef.value}`;
      } else if (nestedContent.type === 'event') {
        storageKey = `comments_${eventIdRef.value}`;
      } else if (nestedContent.type === 'homework') {
        storageKey = `comments_${homeworkIdRef.value}`;
      } else if (nestedContent.type === 'notification') {
        storageKey = `comments_${notificationIdRef.value}`;
      }
      console.log('生成的storageKey值:', storageKey);
      let existingComments = [];
      const existingCommentsStr = localStorage.getItem(storageKey);
      if (existingCommentsStr) {
        try {
          existingComments = JSON.parse(existingCommentsStr);
        } catch (error) {
          console.error(`解析已存在的评论数据（${storageKey}）出错`, error);
          localStorage.removeItem(storageKey);
        }
      }
      existingComments.push(newComment);
      localStorage.setItem(storageKey, JSON.stringify(existingComments));
    } catch (error) {
      console.error('保存评论数据到本地存储失败', error);
      message.error('评论提交失败，请稍后再试');
      return;
    }
    commentText.value = '';
    message.success("评论提交成功");
  } else {
    message.error("评论内容不能为空");
  }
};

// 点赞功能
const zanhandleClick = (event) => {
  if (nestedContent.value) {
    const buttonRect = event.target.getBoundingClientRect();
    const originX = (buttonRect.left + buttonRect.width / 2) / window.innerWidth;
    const originY = (buttonRect.top + buttonRect.height / 2) / window.innerHeight;

    nestedContent.value.likes += 1;
    // 根据不同类型的内容（动态、作业等）去对应的数组里查找并更新点赞数，这里假设当前主要处理的是动态内容点赞，可按需扩展
    const targetArray = getTargetArrayBasedOnType(nestedContent.value);
    const targetIndex = targetArray.findIndex((item) => item.id === nestedContent.value.id);
    if (targetIndex!== -1) {
      targetArray[targetIndex].likes = nestedContent.value.likes;
    }
    message.success("点赞成功");

    const defaults = {
      spread: 360,
      ticks: 20,
      gravity: 0,
      decay: 0.94,
      startVelocity: 30,
      colors: ["#FFE400", "#FFBD00", "#E89400", "#FFCA6C", "#FDFFB8"],
      zIndex: 9999,
    };

    const shoot = () => {
      confetti({
        ...defaults,
        origin: { x: originX, y: originY },
        particleCount: 40,
        scalar: 1.5,
        shapes: ["star"],
      });

      confetti({
        ...defaults,
        origin: { x: originX, y: originY },
        particleCount: 10,
        scalar: 0.95,
        shapes: ["circle"],
      });
    };

    setTimeout(shoot, 0);
    setTimeout(shoot, 100);
    setTimeout(shoot, 200);
  }
};

// 根据内容类型获取对应的存储数组，方便点赞等操作时更新对应数据，可根据实际情况扩展更多类型的处理逻辑
const getTargetArrayBasedOnType = (content) => {
  const type = content.type || 'unknown';
  switch (type) {
    case 'dynamic':
      return userContent.value.dynamic;
    case 'event':
      return userContent.value.event;
    case 'homework':
      return userContent.value.homework;
    case 'notification':
      return userContent.value.notification;
    default:
      return [];
  }
};
</script>

<style scoped>
/* 头部样式 */
.header {
  background-color: #1e90ff;
  width: 100%;
  height: 60px;
  text-align: center;
  color: white;
}

.header h1 {
  margin: 0;
  font-size: 2rem;
}

/* 联系人列表样式 */
.contact-list {
  display: flex;
  flex-direction: column;
}

.contact-item {
  display: flex;
  align-items: center;
  padding: 10px;
  border-bottom: 1px solid #ddd;
  justify-content: space-between;
}

.avatar {
  width: 50px;
  height: 50px;
  object-fit: cover;
  margin-right: 10px;
}

.contact-info {
  display: flex;
  flex-direction: column;
}

.user-name {
  font-weight: bold;
  font-size: 1.1rem;
}

/* 抽屉按钮样式，放在最右边 */
.drawer-button {
  font-size: 1.5rem;
  color: #1e90ff;
  cursor: pointer;
  margin-left: auto;
}

/* 抽屉中的头像样式 */
.drawer-avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-top: 10px;
}

/* 内层抽屉样式（整合了部分第一个代码抽屉相关样式） */
.nested-drawer-header {
  margin-bottom: 16px;
}

.nested-avatar {
  width: 80px;
  height: 80px;
  border-radius: 4px;
  margin-right: 10px;
}

.nested-image {
  width: 100px;
  height: 100px;
  margin-right: 10px;
  margin-bottom: 10px;
}


/* 评论区域样式（整合了第一个代码的相关样式） */
.comment-textarea {
  width: 100%;
  height: 80px;
  padding: 8px;
  font-size: 14px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  resize: none; /* 禁止调整大小 */
  margin-bottom: 10px;
}

.comment-submit-btn {
  display: block;
  width: 100px;
  padding: 6px 12px;
  background-color: #1890ff;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.comment-submit-btn:hover {
  background-color: #40a9ff;
}

.comment-list {
  list-style: none;
  padding: 0;
  margin: 10px 0;
}

.comment-list li {
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
  color: #333;
}
</style>