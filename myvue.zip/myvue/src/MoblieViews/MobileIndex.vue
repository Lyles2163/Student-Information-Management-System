<script setup>
import {Icon} from "vant";
import {useRouter, useRoute} from "vue-router";

const router = useRouter();
const route = useRoute();
// 点击图标事件处理
const onCalendarClick = () => {
  console.log("点击了日历图标");
};

const onScanClick = () => {
  console.log("点击了扫码图标");
};
// 切换选项卡的事件
const onTabChange = (key) => {
  if (key !== route.path) {
    router.push(key); // 切换到对应路径
  }
};
</script>

<template>
  <div class="container">
    <div class="top-bar" style="background:#3ebcf5">
      <!-- 左侧文字 -->
      <div class="top-bar-left">
        朝阳班班 · 计算机应用学院 · 计应2305班
      </div>

      <!-- 右侧图标 -->
      <div class="top-bar-right">
        <van-icon
            name="calendar-o"
            size="20px"
            @click="onCalendarClick"
            class="icon"
        />
        <van-icon
            name="scan"
            size="20px"
            @click="onScanClick"
            class="icon"
        />
      </div>
    </div>

    <div class="carousel-container">
      <a-carousel effect="fade" autoplay :autoplaySpeed="3000">
        <div class="carousel-slide">
          <img
              style="height: 160px"
              src="/assets/media/slideshow/1.png"
              alt="Slide 1"
              class="carousel-image"
          />
          <h3>1</h3>
        </div>
        <div class="carousel-slide">
          <img
              style="height: 160px"
              src="/assets/media/slideshow/2.jpg"
              alt="Slide 2"
              class="carousel-image"
          />
          <h3>2</h3>
        </div>
        <div class="carousel-slide">
          <img
              style="height: 160px"
              src="/assets/media/slideshow/3.jpg"
              alt="Slide 3"
              class="carousel-image"
          />
          <h3>3</h3>
        </div>
        <div class="carousel-slide">
          <img
              style="height: 160px"
              src="/assets/media/slideshow/4.jpg"
              alt="Slide 4"
              class="carousel-image"
          />
          <h3>4</h3>
        </div>
      </a-carousel>
    </div>

    <div style="display: flex; justify-content: center">
      <div
          style="
          display: flex;
          justify-content: space-around;
          align-items: center;
          margin: 10px;
          background: #ffffff;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.07);
          width: 96%;
          border-radius: 8px;
        "
      >
        <div
            style="
      display: flex;
      justify-content: space-around;
      align-items: center;
      margin: 10px;
      background: #ffffff;
      width: 96%;
      border-radius: 8px;
    "
        >
          <!-- 图标和文字 1 -->
          <div style="text-align: center">
            <div
                class="icon-wrapper"
                style="box-shadow: 0 4px 8px rgba(146, 111, 217, 0.8); background: mediumpurple"
            >
              <img src="/assets/icon/TablerAwardFilled.png" alt="TablerAwardFilled"/>
            </div>
            <div style="margin-top: 5px; font-size: 14px; color: #555">课堂评价</div>
          </div>

          <!-- 图标和文字 2 -->
          <div style="text-align: center">
            <div
                class="icon-wrapper"
                style="box-shadow: 0 4px 8px rgba(37, 205, 25, 0.8); background: #25cf19"
            >
              <img src="/assets/icon/MdiCardAccountDetails.png" alt="MdiCardAccountDetails"/>
            </div>
            <div style="margin-top: 5px; font-size: 14px; color: #555">教学备课</div>
          </div>

          <!-- 图标和文字 3 -->
          <div style="text-align: center">
            <div
                class="icon-wrapper"
                style="box-shadow: 0 4px 8px rgba(253, 164, 0, 0.8); background: orange"
            >
              <img src="/assets/icon/MdiImageMultiple.png" alt="MdiImageMultiple"/>
            </div>
            <div style="margin-top: 5px; font-size: 14px; color: #555">班级相册</div>
          </div>

          <!-- 图标和文字 4 -->
          <div style="text-align: center">
            <div
                class="icon-wrapper2"
                style="box-shadow: 0 4px 8px rgba(0, 190, 253, 0.8); background: deepskyblue"
            >
              <img
                  src="/assets/icon/MaterialSymbolsLightDiamondRounded.png"
                  alt="MaterialSymbolsLightDiamondRounded"
              />
            </div>
            <div style="margin-top: 5px; font-size: 14px; color: #555">学谱活动</div>
          </div>
        </div>
      </div>
    </div>

    <div
        style="background: linear-gradient(180deg, #aadefa, #ffffff); width: 100%; display: flex; justify-content: center;">
      <div
          style="width: 96%; background: white; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.07);display: flex;justify-content: center;flex-direction: column">
        <!-- Tabs 组件 -->
        <div>
          <a-tabs
              :active-key="route.path"
              @change="onTabChange"
              tabBarStyle="margin-bottom: 16px ;gap:50px;"
              tabBarGutter="80"
          >
            <a-tab-pane key="/MobileHome/MobileContent/MobileIndex/MobileDynamic" tab="动态"></a-tab-pane>
            <a-tab-pane key="/MobileHome/MobileContent/MobileIndex/MobileActivities" tab="活动"></a-tab-pane>
            <a-tab-pane key="/MobileHome/MobileContent/MobileIndex/MobileAssignments" tab="作业"></a-tab-pane>
            <a-tab-pane key="/MobileHome/MobileContent/MobileIndex/MobileNotifications" tab="通知"></a-tab-pane>
          </a-tabs>
        </div>
        <div style="width: 100%;border-radius: 0; padding:0;">
          <router-view/>
        </div>

      </div>
    </div>
  </div>
</template>

<style scoped>


:deep(.ant-tabs-nav-list) {
  display: flex !important;
  justify-content: center !important;
  gap: 40px !important; /* Tabs 间距 */
  transform: translateX(30px) !important;
}

.container {
  background: linear-gradient(180deg, #28b9f8, #f5f5f5);
}

.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 16px;
  background-color: #fff;
  border-top: 1px solid #eee;
  font-size: 14px;
  color: #333;
}

.top-bar-left {
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.top-bar-right {
  display: flex;
  align-items: center;
}

.icon {
  margin-left: 8px;
  color: #888;
  cursor: pointer;
  transition: color 0.2s;
}

.icon:hover {
  color: #1d92ff;
}

/* 轮播图容器样式 */
.carousel-container {
  display: flex;
  justify-content: center;
  height: 160px;
  margin-top: 10px; /* 增加顶部间距 */
}

.carousel-container > div {
  width: 96%;
  border-radius: 10px;
  height: 160px;
  overflow: hidden; /* 确保圆角效果 */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.48); /* 可选：添加阴影效果 */
}

/* 幻灯片样式 */
:deep(.slick-slide) {
  text-align: center;
  height: 160px;
  line-height: 160px;
  overflow: hidden;
  border-radius: 10px; /* 添加圆角 */
}

.carousel-slide {
  position: relative;
}

.carousel-image {
  width: 100%;
  height: auto;
  display: block;
  border-radius: 10px; /* 为图片添加圆角 */
}

/* 图标容器样式 */
.icon-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 60px;
  width: 60px;
  margin: 8px;
  border-radius: 50%;
}

.icon-wrapper2 {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 60px;
  width: 60px;
  margin: 8px;
  border-radius: 50%;
}

.icon-wrapper img {
  max-width: 60%;
  max-height: 60%;
  object-fit: contain;
  display: block;
}

.icon-wrapper2 img {
  max-width: 70%;
  max-height: 70%;
  object-fit: contain;
  display: block;
}
</style>
