<template>
  <div class="dynamic-container">
    <!-- 显示加载动画 -->
    <div v-if="isLoading" class="loading-overlay" :class="{ 'fade-out':!isLoading }">
      <img src="/assets/media/loading3.gif" alt="加载中..." class="loading-gif"/>
    </div>
    <div v-if="isLoading2" class=" loading-overlay2" :class="{ 'fade-out':!isLoading2 }">
      <img src="/assets/media/loading12.gif" alt="加载中..." class="loading-gif"/>
    </div>

    <!-- 事件卡片列表 -->
    <a-card
        v-for="event in userEvents"
        :key="event.eventId"
        class="dynamic-card"
        style="border-radius: 0;
      border: transparent;
      background:
      linear-gradient(to right,
      rgba(108,108,108,0.5) 0%,
      rgba(255,0,0,0.5) 50%,
      rgba(108,108,108,0.5) 100%);
    background-repeat: no-repeat;
    background-position: center bottom;
    background-size: 80% 0.02rem;">
      <a-row>
        <!-- 头像区域 -->
        <a-col :span="6" class="avatar-col">
          <a-avatar :src="event.avatarUrl" style="width: 60px; height: 60px;"/>
        </a-col>

        <!-- 内容区域 -->
        <a-col :span="16" class="content-col">
          <a-card-meta
              :title="event.name"
              :description="event.createTime"
              class="meta-info"
          />

          <!-- 事件标题和简要内容 -->
          <div class="dynamic-details">
            <h4 style="margin-bottom: 8px;color: #050533;font-weight: 900;letter-spacing: 3px" @click="openDetailDrawer(event)">  {{ event.title }}</h4>
            <p>{{ event.content.length > 10? event.content.slice(0, 10) + "..." : event.content }}</p>
          </div>

          <!-- 图片展示 -->
          <div v-if="event.imageUrls && event.imageUrls.length > 0" class="image-container">
            <a-image-preview-group>
              <a-image
                  v-for="(imageUrl, index) in event.imageUrls.slice(0, 1)"
                  :key="index"
                  :src="imageUrl"
                  :alt="'图片 ' + (index + 1)"
                  width="40px"
                  height="40px"
                  style="margin-right: 10px; border-radius: 4px;box-shadow: black 0 0 2px 0px"
              />
            </a-image-preview-group>
          </div>


        </a-col>
      </a-row>
    </a-card>

    <!-- 抽屉：显示详细内容 -->
    <a-drawer
        title="事件详情"
        placement="right"
        :closable="true"
        :visible="isDrawerVisible"
        @close="closeDetailDrawer"
        width="100%"
    >
      <div v-if="selectedEvent">
        <a-card hoverable style="margin-bottom: 16px;">
          <a-row align="middle" :gutter="16">
            <a-col :span="4">
              <a-avatar :src="selectedEvent.avatarUrl" size="large"/>
            </a-col>
            <a-col :span="20">
              <h3>{{ selectedEvent.title }}</h3>
              <p style="color: #888; margin: 0;">发布人：{{ selectedEvent.username }} <br>
                发布时间：{{ selectedEvent.createTime }}</p>
            </a-col>
          </a-row>
        </a-card>

        <a-divider orientation="left">内容</a-divider>
        <p style="font-size: 14px; line-height: 1.6;">{{ selectedEvent.content }}</p>

        <div v-if="selectedEvent.imageUrls.length > 0">
          <a-divider orientation="left">图片展示</a-divider>
          <a-image-preview-group>
            <a-row :gutter="[10, 10]">
              <a-col v-for="(imageUrl, index) in selectedEvent.imageUrls" :key="index" :span="8">
                <a-image
                    :src="imageUrl"
                    :alt="'详细图片 ' + (index + 1)"
                    style="border-radius: 8px;"
                />
              </a-col>
            </a-row>
          </a-image-preview-group>
        </div>

        <a-divider orientation="left">💬 评论区</a-divider>
        <div>
          <textarea
              v-model="newComment"
              placeholder="输入您的评论"
              rows="3"
              class="comment-textarea"
          ></textarea>
          <button class="comment-submit-btn" @click="submitComment">
            提交评论
          </button>
          <div style="text-align: center; margin-top: 20px;">
            <a-button type="primary" shape="round" size="large" @click="zanhandleClick">
              👍 点赞 ({{ selectedEvent.likes }})
            </a-button>
          </div>
        </div>

        <ul class="comment-list">
          <li v-for="(comment, index) in selectedEvent.comments" :key="index" style="display: flex; align-items: flex-start; margin-bottom: 10px;">
            <a-avatar :src="comment.avatarUrl" style="margin-right: 10px;" size="small" />
            <div>
              <p style="margin: 0; color: #666;">
                <strong>{{ comment.username }}</strong>
                <span style="font-size: 12px; color: #aaa; margin-left: 10px;">{{ comment.time }}</span>
              </p>
              <p style="margin: 0; color: #333;">{{ comment.content }}</p>
            </div>
          </li>
        </ul>
        <p v-if="!selectedEvent.comments.length" style="text-align: center; color: #aaa;">
          暂无评论
        </p>
      </div>
    </a-drawer>
  </div>
</template>

<script setup>
import { ref, onMounted, reactive } from "vue";
import { Card, Row, Col, Avatar, Button, Drawer, Input, message, Image, Divider, List } from "ant-design-vue";
import confetti from "canvas-confetti";

const { TextArea } = Input;

const isLoading = ref(false); // 加载状态
const isLoading2 = ref(false); // 加载状态
const userEvents = ref([]);
const isDrawerVisible = ref(false);
const selectedEvent = ref(null);
const newComment = ref("");

const fetchUserEvents = async () => {
  isLoading2.value = true;
  setTimeout(async () => {
    const response = await fetch("http://localhost/backend/getAllEvents.php");
    const data = await response.json();
    if (data.status === "success") {
      userEvents.value = data.userEvents.map((event) => ({
        ...event,
        imageUrls: JSON.parse(event.imageUrls || "[]"),
        likes: event.likes || 0,
        comments: [],
      }));
    } else {
      console.error("获取事件失败", data.message);
    }
    isLoading2.value = false;
  }, 600);
};

const openDetailDrawer = (event) => {
  selectedEvent.value = {...event };
  const storedComments = loadCommentsFromLocalStorage(event.eventId);
  if (storedComments) {
    selectedEvent.value.comments = storedComments;
  }
  isDrawerVisible.value = true;
};

const loadCommentsFromLocalStorage = (eventId) => {
  const storageKey = `comments_${eventId}`;
  const storedData = localStorage.getItem(storageKey);
  return storedData? JSON.parse(storedData) : [];
};

const closeDetailDrawer = () => {
  isDrawerVisible.value = false;
  selectedEvent.value = null;
};

const submitComment = () => {
  if (newComment.value.trim()) {
    isLoading.value = true; // 提交评论时显示加载动画
    setTimeout(() => {
      if (!selectedEvent.value.comments) {
        selectedEvent.value.comments = [];
      }

      const now = new Date();
      const commentTime = now.toLocaleString();

      const newCommentObj = {
        content: newComment.value.trim(),
        avatarUrl: localStorage.getItem("avatarUrl") || "",
        username: localStorage.getItem("currentUsername") || "匿名用户",
        time: commentTime,
      };

      selectedEvent.value.comments.push(newCommentObj);
      saveCommentsToLocalStorage(selectedEvent.value.eventId, selectedEvent.value.comments);
      newComment.value = "";
      message.success("评论提交成功");
      isLoading.value = false; // 隐藏加载动画
    }, 1050); // 模拟网络延迟
  } else {
    message.error("评论内容不能为空");
  }
};

const saveCommentsToLocalStorage = (eventId, comments) => {
  const storageKey = `comments_${eventId}`;
  localStorage.setItem(storageKey, JSON.stringify(comments));
};

const zanhandleClick = (event) => {
  const buttonRect = event.target.getBoundingClientRect();
  const originX = (buttonRect.left + buttonRect.width / 2) / window.innerWidth;
  const originY = (buttonRect.top + buttonRect.height / 2) / window.innerHeight;

  if (selectedEvent.value) {
    selectedEvent.value.likes += 1;
    const targetEvent = userEvents.value.find((item) => item.eventId === selectedEvent.value.eventId);
    if (targetEvent) {
      targetEvent.likes = selectedEvent.value.likes;
    }
    message.success("点赞成功");

    const defaults = {
      spread: 360,
      ticks: 20,
      gravity: 0,
      decay: 0.94,
      startVelocity: 30,
      colors: ["#FFE400", "#FFBD00", "#E89400", "#FFCA6C", "#FDFFB8"],
      zIndex: 9999,
    };

    const shoot = () => {
      confetti({
        ...defaults,
        origin: { x: originX, y: originY },
        particleCount: 40,
        scalar: 1.5,
        shapes: ["star"],
      });

      confetti({
        ...defaults,
        origin: { x: originX, y: originY },
        particleCount: 10,
        scalar: 0.95,
        shapes: ["circle"],
      });
    };

    setTimeout(shoot, 0);
    setTimeout(shoot, 100);
    setTimeout(shoot, 200);
  }
};

onMounted(() => {
  fetchUserEvents();
});
</script>

<style scoped>
/* 加载覆盖层样式 */
.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999; /* 确保在最上层 */
  transition: opacity 0.2s ease-out;
}
.loading-overlay2{
  position: relative;
  top: 70%;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0);
  display: flex;
  justify-content: center;
  z-index: 9999; /* 确保在最上层 */
  transition: opacity 0.2s ease-out;
}
.loading-overlay.loading-gif {
  width: 100px;
  height: 100px;
}

.loading-overlay.fade-out {
  opacity: 0;
  pointer-events: none;
}
.dynamic-container {
  margin-bottom: 0;
  padding: 0;
  width: 100%;
  background-color: #f9f9f9;

}

.comment-input {
  margin-bottom: 10px;
}

.comment-list {
  list-style: none;
  padding: 0;
}

.comment-list li {
  padding: 8px 12px;
  border-bottom: 1px solid #f0f0f0;
  color: #333;
}

.comment-list li:last-child {
  border-bottom: none;
}
.comment-textarea {
  width: 100%;
  height: 80px;
  padding: 8px;
  font-size: 14px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  resize: none; /* 禁止调整大小 */
  margin-bottom: 10px;
}

.comment-submit-btn {
  display: block;
  width: 100px;
  padding: 6px 12px;
  background-color: #1890ff;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.comment-submit-btn:hover {
  background-color: #40a9ff;
}

.comment-list {
  list-style: none;
  padding: 0;
  margin: 10px 0;
}

.comment-list li {
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
  color: #333;
}

</style>