<template>
  <div class="dynamic-container">
    <!-- 显示加载动画 -->
    <div v-if="isLoading" class="loading-overlay" :class="{ 'fade-out':!isLoading }">
      <img src="/assets/media/loading3.gif" alt="加载中..." class="loading-gif"/>
    </div>
    <div v-if="isLoading2" class="loading-overlay2" :class="{ 'fade-out':!isLoading2 }">
      <img src="/assets/media/loading11.gif" alt="加载中..." class="loading-gif"/>
    </div>

    <!-- 动态卡片列表 -->
    <a-card
        v-for="dynamic in userDynamics"
        :key="dynamic.dynamicId"
        class="dynamic-card"
        style="border-radius: 0;
      border: transparent;
      background:
      linear-gradient(to right,
      rgba(108,108,108,0.5) 0%,
      rgba(255,0,0,0.5) 50%,
      rgba(108,108,108,0.5) 100%);
    background-repeat: no-repeat;
    background-position: center bottom;
    background-size: 80% 0.02rem;">
      <a-row>
        <!-- 头像区域 -->
        <a-col :span="6" class="avatar-col">
          <a-avatar :src="dynamic.avatarUrl" style="width: 60px; height: 60px;"/>
        </a-col>

        <!-- 内容区域 -->
        <a-col :span="16" class="content-col">
          <a-card-meta
              :title="dynamic.name"
              :description="dynamic.createTime"
              class="meta-info"
          />

          <!-- 动态标题和简要内容 -->
          <div class="dynamic-details">
            <h4 style="margin-bottom: 8px;color: #050533;font-weight: 900;letter-spacing: 3px" @click="openDetailDrawer(dynamic)"> {{ dynamic.title }}</h4>
            <p>{{ dynamic.content.length > 10? dynamic.content.slice(0, 10) + "..." : dynamic.content }}</p>
          </div>

          <!-- 图片展示 -->
          <div v-if="dynamic.imageUrls && dynamic.imageUrls.length > 0" class="image-container">
            <a-image-preview-group>
              <a-image
                  v-for="(imageUrl, index) in dynamic.imageUrls.slice(0, 1)"
                  :key="index"
                  :src="imageUrl"
                  :alt="'图片 ' + (index + 1)"
                  width="40px"
                  height="40px"
                  style="margin-right: 10px; border-radius: 4px;box-shadow: black 0 0 2px 0px"
              />
            </a-image-preview-group>
          </div>


        </a-col>
      </a-row>
    </a-card>

    <!-- 抽屉：显示详细内容 -->
    <a-drawer
        title="动态详情"
        placement="right"
        :closable="true"
        :visible="isDrawerVisible"
        @close="closeDetailDrawer"
        width="100%"
    >
      <div v-if="selectedDynamic">
        <a-card hoverable style="margin-bottom: 16px;">
          <a-row align="middle" :gutter="16">
            <a-col :span="4">
              <a-avatar :src="selectedDynamic.avatarUrl" size="large"/>
            </a-col>
            <a-col :span="20">
              <h3>{{ selectedDynamic.title }}</h3>
              <p style="color: #888; margin: 0;">发布人：{{ selectedDynamic.username }} <br>
                发布时间：{{ selectedDynamic.createTime }}</p>
            </a-col>
          </a-row>
        </a-card>

        <a-divider orientation="left">内容</a-divider>
        <p style="font-size: 14px; line-height: 1.6;">{{ selectedDynamic.content }}</p>

        <div v-if="selectedDynamic.imageUrls.length > 0">
          <a-divider orientation="left">图片展示</a-divider>
          <a-image-preview-group>
            <a-row :gutter="[10, 10]">
              <a-col v-for="(imageUrl, index) in selectedDynamic.imageUrls" :key="index" :span="8">
                <a-image
                    :src="imageUrl"
                    :alt="'详细图片 ' + (index + 1)"
                    style="border-radius: 8px;"
                />
              </a-col>
            </a-row>
          </a-image-preview-group>
        </div>

        <a-divider orientation="left">💬 评论区</a-divider>
        <div>
          <textarea
              v-model="newComment"
              placeholder="输入您的评论"
              rows="3"
              class="comment-textarea"
          ></textarea>
          <button class="comment-submit-btn" @click="submitComment">
            提交评论
          </button>
          <div style="text-align: center; margin-top: 20px;">
            <a-button type="primary" shape="round" size="large" @click="zanhandleClick">
              👍 点赞 ({{ selectedDynamic.likes }})
            </a-button>
          </div>
        </div>

        <ul class="comment-list">
          <li v-for="(comment, index) in selectedDynamic.comments" :key="index" style="display: flex; align-items: flex-start; margin-bottom: 10px;">
            <a-avatar :src="comment.avatarUrl" style="margin-right: 10px;" size="small" />
            <div>
              <p style="margin: 0; color: #666;">
                <strong>{{ comment.username }}</strong>
                <span style="font-size: 12px; color: #aaa; margin-left: 10px;">{{ comment.time }}</span>
              </p>
              <p style="margin: 0; color: #333;">{{ comment.content }}</p>
            </div>
          </li>
        </ul>
        <p v-if="!selectedDynamic.comments.length" style="text-align: center; color: #aaa;">
          暂无评论
        </p>
      </div>
    </a-drawer>
  </div>
</template>

<script setup>
import { ref, onMounted, reactive } from "vue";
import { Card, Row, Col, Avatar, Button, Drawer, Input, message, Image, Divider, List } from "ant-design-vue";
import confetti from "canvas-confetti";

const { TextArea } = Input;

const isLoading = ref(false); // 加载状态
const isLoading2 = ref(false); // 加载状态
const userDynamics = ref([]);
const isDrawerVisible = ref(false);
const selectedDynamic = ref(null);
const newComment = ref("");

// 从本地存储获取所有动态数据（假设之前已经保存过完整的动态数据列表到本地存储）
const fetchUserDynamicsFromLocalStorage = () => {
  const storedData = localStorage.getItem('userDynamics');
  if (storedData) {
    userDynamics.value = JSON.parse(storedData).map((dynamic) => ({
      ...dynamic,
      imageUrls: JSON.parse(dynamic.imageUrls || "[]"),
      likes: dynamic.likes || 0,
      comments: [], // 先初始化为空数组，后续再从单独的评论缓存中获取填充
    }));
  }
};

// 从本地存储获取单个动态的评论数据并填充到对应的动态对象中
const fetchCommentsForDynamics = () => {
  userDynamics.value.forEach((dynamic) => {
    const storageKey = `comments_${dynamic.dynamicId}`;
    const storedComments = localStorage.getItem(storageKey);
    if (storedComments) {
      dynamic.comments = JSON.parse(storedComments);
    }
  });
};

const fetchUserDynamics = async () => {
  isLoading2.value = true;
  setTimeout(async () => {
    try {
      const response = await fetch("http://localhost/backend/getAllDynamics.php");
      const data = await response.json();
      if (data.status === "success") {
        userDynamics.value = data.userDynamics.map((dynamic) => ({
          ...dynamic,
          imageUrls: JSON.parse(dynamic.imageUrls || "[]"),
          likes: dynamic.likes || 0,
          comments: [],
        }));
        // 成功获取后端数据后，将数据保存到本地存储
        localStorage.setItem('userDynamics', JSON.stringify(userDynamics.value));
      } else {
        console.error("获取动态失败", data.message);
        // 如果后端获取失败，尝试从本地存储获取数据
        fetchUserDynamicsFromLocalStorage();
        fetchCommentsForDynamics();
      }
    } catch (error) {
      console.error("获取动态时发生网络错误", error);
      // 网络错误时也尝试从本地存储获取数据
      fetchUserDynamicsFromLocalStorage();
      fetchCommentsForDynamics();
    } finally {
      isLoading2.value = false;
    }
  }, 600);
};

const openDetailDrawer = (dynamic) => {
  selectedDynamic.value = {...dynamic };
  const storedComments = localStorage.getItem(`comments_${dynamic.dynamicId}`);
  if (storedComments) {
    selectedDynamic.value.comments = JSON.parse(storedComments);
  }
  isDrawerVisible.value = true;
};

const closeDetailDrawer = () => {
  isDrawerVisible.value = false;
  selectedDynamic.value = null;
};

const submitComment = () => {
  const commentText = newComment.value.trim();
  if (commentText) {
    // 简单校验评论内容长度，比如限制最长200字（可根据实际需求调整）
    if (commentText.length > 200) {
      message.error("评论内容过长，请控制在200字以内");
      return;
    }
    isLoading.value = true; // 提交评论时显示加载动画
    setTimeout(() => {
      if (!selectedDynamic.value.comments) {
        selectedDynamic.value.comments = [];
      }

      const now = new Date();
      const commentTime = now.toLocaleString();

      const newCommentObj = {
        content: commentText,
        avatarUrl: localStorage.getItem("avatarUrl") || "",
        username: localStorage.getItem("currentUsername") || "匿名用户",
        time: commentTime,
      };

      selectedDynamic.value.comments.push(newCommentObj);
      localStorage.setItem(`comments_${selectedDynamic.value.dynamicId}`, JSON.stringify(selectedDynamic.value.comments));
      newComment.value = "";
      message.success("评论提交成功");
      isLoading.value = false; // 隐藏加载动画
    }, 1050); // 模拟网络延迟
  } else {
    message.error("评论内容不能为空");
  }
};

const zanhandleClick = (event) => {
  const buttonRect = event.target.getBoundingClientRect();
  const originX = (buttonRect.left + buttonRect.width / 2) / window.innerWidth;
  const originY = (buttonRect.top + buttonRect.height / 2) / window.innerHeight;

  if (selectedDynamic.value) {
    selectedDynamic.value.likes += 1;
    const dynamicIndex = userDynamics.value.findIndex((item) => item.dynamicId === selectedDynamic.value.dynamicId);
    if (dynamicIndex!== -1) {
      userDynamics.value[dynamicIndex].likes = selectedDynamic.value.likes;
      localStorage.setItem('userDynamics', JSON.stringify(userDynamics.value));
    }
    message.success("点赞成功");

    const defaults = {
      spread: 360,
      ticks: 20,
      gravity: 0,
      decay: 0.94,
      startVelocity: 30,
      colors: ["#FFE400", "#FFBD00", "#E89400", "#FFCA6C", "#FDFFB8"],
      zIndex: 9999,
    };

    const shoot = () => {
      confetti({
        ...defaults,
        origin: { x: originX, y: originY },
        particleCount: 40,
      });

      confetti({
        ...defaults,
        origin: { x: originX, y: originY },
        particleCount: 10,
      });
    };

    setTimeout(shoot, 0);
    setTimeout(shoot, 100);
    setTimeout(shoot, 200);
  }
};

onMounted(() => {
  fetchUserDynamics();
});
</script>

<style scoped>
/* 加载覆盖层样式 */
.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999; /* 确保在最上层 */
  transition: opacity 0.2s ease-out;
}
.loading-overlay2 {
  position: relative;
  top: 70%;
  width: 100%;
  height: 100%;
  background: rgba(255, 255, 255, 0);
  display: flex;
  justify-content: center;
  z-index: 9999; /* 确保在最上层 */
  transition: opacity 0.2s ease-out;
}
.loading-overlay.loading-gif {
  width: 100px;
  height: 100px;
}

.loading-overlay.fade-out {
  opacity: 0;
  pointer-events: none;
}
.dynamic-container {
  margin-bottom: 0;
  padding: 0;
  width: 100%;
  background-color: #f9f9f9;

}

.comment-input {
  margin-bottom: 10px;
}

.comment-list {
  list-style: none;
  padding: 0;
}

.comment-list li {
  padding: 8px 12px;
  border-bottom: 1px solid #f0f0f0;
  color: #333;
}

.comment-list li:last-child {
  border-bottom: none;
}
.comment-textarea {
  width: 100%;
  height: 80px;
  padding: 8px;
  font-size: 14px;
  border: 1px solid #d9d9d9;
  border-radius: 4px;
  resize: none; /* 禁止调整大小 */
  margin-bottom: 10px;
}

.comment-submit-btn {
  display: block;
  width: 100px;
  padding: 6px 12px;
  background-color: #1890ff;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.comment-submit-btn:hover {
  background-color: #40a9ff;
}

.comment-list {
  list-style: none;
  padding: 0;
  margin: 10px 0;
}

.comment-list li {
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
  color: #333;
}

</style>