<template>
  <div class="chat-container">
    <!-- 消息列表 -->
    <ul class="chat-list">
      <li v-for="item in messages" :key="item.id" class="message">
        <img :src="item.avatarUrl" alt="avatar" class="avatar" />
        <div class="content">
          <div class="username">{{ item.username }}</div>
          <div class="text">{{ item.message }}</div>
          <div class="time">{{ formatTime(item.create_time) }}</div>
        </div>
      </li>
    </ul>

    <!-- 输入框和发送按钮 -->
    <div class="input-container">
      <textarea
          v-model="newMessage"
          placeholder="请输入消息"
          class="message-input"
          rows="2"
          @keyup.enter="handleSendMessage"
      ></textarea>
      <button
          class="send-button"
          @click="handleSendMessage"
          :disabled="newMessage.trim() === ''"
      >
        发送
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

const messages = ref([]); // 聊天消息列表
const newMessage = ref(""); // 当前输入的消息

const senderId = 1; // 假设当前用户的 ID 是 1（可动态设置）


// 格式化时间
const formatTime = (time) => {
  return new Date(time).toLocaleString();
};

// 获取消息列表
const loadMessages = async () => {
  try {
    const res = await axios.get(`http://localhost/backend/getMessages.php`);
    messages.value = res.data.messages;
  } catch (err) {
    alert("消息加载失败，请重试！");
  }
};

// 发送消息
const handleSendMessage = async () => {
  if (!newMessage.value.trim()) return;

  try {
    await axios.post(`http://localhost/backend/sendMessages.php`, {
      sender_id: senderId,
      message: newMessage.value.trim(),
    });
    newMessage.value = ""; // 清空输入框
    alert("消息发送成功！");
    loadMessages(); // 重新加载消息列表
  } catch (err) {
    alert("消息发送失败，请重试！");
  }
};

// 初始化加载消息
onMounted(() => {
  loadMessages();
});
</script>

<style scoped>
.chat-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background-color: #f5f5f5;
}

.chat-list {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  list-style-type: none;
  margin: 0;
}

.message {
  display: flex;
  margin-bottom: 12px;
}

.avatar {
  margin-right: 12px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
}

.content {
  display: flex;
  flex-direction: column;
}

.username {
  font-weight: bold;
  color: #1890ff;
}

.text {
  margin: 4px 0;
}

.time {
  font-size: 12px;
  color: gray;
}

.input-container {
  display: flex;
  padding: 12px;
  transform: translateY(-80px);
  background-color: white;
  border-top: 1px solid #ddd;
}

.message-input {
  flex: 1;
  margin-right: 8px;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.send-button {
  padding: 8px 16px;
  background-color: #1890ff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.send-button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}
</style>
