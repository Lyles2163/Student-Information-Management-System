<template>
  <div class="user-profile">
    <div style="display: flex; justify-content: center; align-items: center; background-color: #1890ff; color: white; height: 60px; padding: 0 20px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
      <div style="font-size: 20px; font-weight: bold;">
        个人中心
      </div>
    </div>
    <!-- 个人信息模块 -->
    <a-card v-if="userData.id" :bordered="false" class="user-info-card">
      <div class="user-info">
        <!-- 左侧头像展示 -->
        <a-avatar
            :src="userData.avatarUrl || 'https://example.com/default-avatar.png'"
            class="avatar"
            style="width: 80px;height: 80px"
            shape="square"
        />
        <!-- 右侧用户信息展示 -->
        <div class="user-details">
          <div class="user-name">
            <span class="username">{{ userData.username }}</span>
          </div>
          <div class="user-wechat">
            <span>账号: {{ userData.userAccount }}</span>
          </div>
          <div style="display: flex; justify-content: flex-end;">
            <a-button type="link" @click="editField"> 修改信息 </a-button>
          </div>
        </div>
      </div>
    </a-card>

    <!-- 下方功能模块 -->
    <a-card title="功能模块" bordered="false" class="function-module-card">
      <a-list>
        <a-list-item @click="navigateTo('service')">
          <a-list-item-meta title="服务" />
        </a-list-item>
        <a-list-item @click="navigateTo('collections')">
          <a-list-item-meta title="收藏" />
        </a-list-item>
        <a-list-item @click="navigateTo('friends')">
          <a-list-item-meta title="朋友圈" />
        </a-list-item>
        <a-list-item @click="navigateTo('video')">
          <a-list-item-meta title="视频号" />
        </a-list-item>
        <a-list-item @click="navigateTo('orders')">
          <a-list-item-meta title="订单与卡包" />
        </a-list-item>
        <a-list-item @click="navigateTo('settings')">
          <a-list-item-meta title="设置" />
        </a-list-item>
      </a-list>
    </a-card>

    <!-- 修改信息的抽屉 -->
    <a-drawer
        title="修改信息"
        placement="right"
        :visible="visible"
        @close="onClose"
        width="100%"
        :body-style="{ background: '#f0f2f5', padding: '20px' }"
    >
      <a-form :model="formState" layout="vertical" @submit="submitForm">
        <!-- 用户名 -->
        <a-form-item label="用户名" :rules="[ { required: true, message: '请输入用户名' } ]">
          <a-input v-model:value="formState.username" placeholder="输入用户名" />
        </a-form-item>

        <!-- 年龄 -->
        <a-form-item label="年龄" :rules="[ { required: true, message: '请输入年龄' }, { type: 'number', min: 1, max: 120, message: '请输入有效年龄' } ]">
          <a-input-number v-model:value="formState.age" :min="1" :max="120" style="width: 100%" />
        </a-form-item>

        <!-- 用户账号 -->
        <a-form-item label="用户账号" :rules="[ { required: true, message: '请输入账号' } ]">
          <a-input v-model:value="formState.userAccount" placeholder="输入用户账号" />
        </a-form-item>

        <!-- 性别 -->
        <a-form-item label="性别">
          <a-radio-group v-model:value="formState.gender">
            <a-radio value="男">男</a-radio>
            <a-radio value="女">女</a-radio>
          </a-radio-group>
        </a-form-item>

        <!-- 密码 -->
        <a-form-item label="密码" :rules="[ { required: true, message: '请输入密码' }, { min: 6, message: '密码至少6个字符' } ]">
          <a-input-password v-model:value="formState.userPassword" placeholder="输入新密码" />
        </a-form-item>

        <!-- 确认密码 -->
        <a-form-item label="确认密码" :rules="[ { required: true, message: '请确认密码' }, { validator: validatePassword, message: '密码不一致' } ]">
          <a-input-password v-model:value="formState.confirmPassword" placeholder="确认密码" />
        </a-form-item>
      </a-form>

      <template #footer>
        <a-button style="margin-right: 8px" @click="onClose" :style="{ background: '#1890ff', color: '#fff' }"> 取消 </a-button>
        <a-button type="primary" @click="submitForm" :style="{ background: '#1890ff', color: '#fff' }"> 保存 </a-button>
      </template>
    </a-drawer>
  </div>
</template>

<script setup>
import {ref, onMounted} from 'vue';
import axios from 'axios';
import { message } from 'ant-design-vue';

const userData = ref({
  id: null,
  username: '',
  age: null,
  userAccount: '',
  avatarUrl: '',
  gender: '',
  createTime: '',
  userRole: '',
});

const visible = ref(false); // 抽屉显示状态
const formState = ref({
  username: '',
  age: null,
  userAccount: '',
  gender: '',
  userPassword: '',
  confirmPassword: '', // 新增确认密码字段
});

// 获取用户数据
const fetchUserData = async () => {
  const userId = localStorage.getItem('userID');
  if (!userId) {
    message.error('用户ID未缓存成功');
    return;
  }
  try {
    const response = await axios.get(`http://localhost/backend/mobileGetUser.php?id=${userId}`);
    if (response.data.code === 200) {
      userData.value = response.data.data;
      formState.value = {...userData.value, userPassword: '', confirmPassword: ''}; // 清空密码相关字段
    } else {
      message.error(response.data.message || '用户信息不存在');
    }
  } catch (error) {
    message.error('获取用户信息失败');
  }
};

// 显示抽屉并准备表单数据
const editField = () => {
  visible.value = true;
  formState.value = {...userData.value, userPassword: '', confirmPassword: ''};
};

// 关闭抽屉
const onClose = () => {
  visible.value = false;
};

// 提交表单修改
const submitForm = async () => {
  const userId = localStorage.getItem('userID');
  // 验证密码是否一致
  if (formState.value.userPassword !== formState.value.confirmPassword) {
    message.error('密码不一致');
    return;
  }

  try {
    const response = await axios.post('http://localhost/backend/mobileUpdateUser.php', {
      id: userId,
      ...formState.value,
    });
    if (response.data.code === 200) {
      message.success('信息修改成功');
      fetchUserData();
      onClose();
    } else {
      message.error('信息修改失败');
    }
  } catch (error) {
    message.error('信息修改失败');
  }
};

// 跳转到不同的模块（模拟）
const navigateTo = (module) => {
  message.info(`跳转到：${module}`);
};

// 页面挂载时获取用户数据
onMounted(() => {
  fetchUserData();
});

// 校验密码是否一致
const validatePassword = (_, value) => {
  if (!value || value === formState.value.userPassword) {
    return Promise.resolve();
  }
  return Promise.reject('密码不一致');
};

</script>

<style scoped>
.user-profile {

  height: calc(100vh - 64px);
  width: 100%;
  background-color: #f0f2f5;
}

.user-info-card {
  margin-bottom: 16px;
  background-color: #ffffff;
}

.function-module-card {
  margin-top: 16px;
  background-color: #ffffff;
}

/* 调整头像和用户信息的布局 */
.user-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.avatar {
  margin-right: 20px;
}

.user-details {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

/* 让更多信息的切换按钮居中 */
.username {
  font-size: 18px;
  font-weight: bold;
  color: #333;
}

.user-wechat {
  margin-top: 10px;
  font-size: 14px;
  color: #666;
}

a-button {
  border-radius: 4px;
}

a-button:hover {
  background-color: #1890ff;
  color: #ffffff;
}

a-list-item-meta {
  font-size: 16px;
  color: #1890ff;
}
</style>
