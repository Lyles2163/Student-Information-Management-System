<template>
  <a-card title="" class="auth-card" style="background: transparent;border: transparent">
    <a-form :model="formState" layout="vertical" @submit="onLogin">
      <!-- 用户名输入框 -->
      <a-form-item label="用户名" name="username">
        <a-input
            v-model:value="formState.username"
            placeholder="请输入用户名"
            allow-clear
        >
          <template #prefix>
            <UserOutlined />
          </template>
        </a-input>
      </a-form-item>

      <!-- 密码输入框 -->
      <a-form-item label="密码" name="password">
        <a-input-password
            v-model:value="formState.password"
            placeholder="请输入密码"
            allow-clear
        >
          <template #prefix>
            <LockOutlined />
          </template>
        </a-input-password>
      </a-form-item>

      <!-- 登录按钮 -->
      <a-form-item>
        <a-button type="primary" html-type="submit" block>登录</a-button>
      </a-form-item>
    </a-form>
  </a-card>
</template>

<script setup>
import { ref } from "vue";
import { message } from "ant-design-vue";
import { UserOutlined, LockOutlined } from "@ant-design/icons-vue";
import { useUserStore } from "../../stores/userStore";
import router from "../../router/router.js";

const userStore = useUserStore();

// 表单状态
const formState = ref({
  username: "",
  password: "",
});

// 登录逻辑
const onLogin = async (event) => {

  const { username, password } = formState.value;

  if (!username || !password) {
    message.error("请输入用户名和密码");
    return;
  }

  try {
    await userStore.login(username, password);
    // message.success("登录成功");
  router.push("/MobileHome/MobileContent/MobileIndex/MobileDynamic");
  } catch (error) {
    message.error("登录失败，请检查用户名和密码");
  }
};
</script>

<style scoped>
.auth-card {

  margin: 50px auto;
}
</style>
