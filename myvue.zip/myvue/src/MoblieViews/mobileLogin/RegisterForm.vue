<template>
  <a-card title="" class="auth-card" style="background: transparent;border: transparent">
    <a-form :model="formState" layout="vertical" @submit="onRegister">
      <!-- 用户账号 -->
      <a-form-item label="用户账号" name="userAccount">
        <a-input
            v-model:value="formState.userAccount"
            placeholder="请输入用户账号"
            allow-clear
        >
          <template #prefix>
            <UserOutlined />
          </template>
        </a-input>
      </a-form-item>

      <!-- 手机号 -->
      <a-form-item label="手机号" name="phone">
        <a-input
            v-model:value="formState.phone"
            placeholder="请输入手机号"
            allow-clear
        >
          <template #prefix>
            <PhoneOutlined />
          </template>
        </a-input>
      </a-form-item>

      <!-- 验证码 -->
      <a-form-item label="验证码" name="code">
        <div style="display: flex; gap: 8px;">
          <a-input
              v-model:value="formState.code"
              placeholder="请输入验证码"
              allow-clear
          />
          <a-button
              type="primary"
              @click="sendCode"
              :disabled="isSendingCode"
          >
            {{ isSendingCode ? `${countdown}秒后重试` : "获取验证码" }}
          </a-button>
        </div>
      </a-form-item>

      <!-- 密码 -->
      <a-form-item label="密码" name="registerPassword">
        <a-input-password
            v-model:value="formState.registerPassword"
            placeholder="请输入密码"
        >
          <template #prefix>
            <LockOutlined />
          </template>
        </a-input-password>
      </a-form-item>

      <!-- 确认密码 -->
      <a-form-item label="确认密码" name="confirmPassword">
        <a-input-password
            v-model:value="formState.confirmPassword"
            placeholder="请确认密码"
        >
          <template #prefix>
            <LockOutlined />
          </template>
        </a-input-password>
      </a-form-item>

      <!-- 提交按钮 -->
      <a-form-item>
        <a-button type="primary" html-type="submit" block>注册</a-button>
      </a-form-item>
    </a-form>
  </a-card>
</template>

<script setup>
import { ref } from "vue";
import { message } from "ant-design-vue";
import { UserOutlined, PhoneOutlined, LockOutlined } from "@ant-design/icons-vue";
import axios from "axios";

// 表单状态
const formState = ref({
  userAccount: "",
  phone: "",
  code: "",
  registerPassword: "",
  confirmPassword: "",
});

// 验证码状态
const isSendingCode = ref(false);
const countdown = ref(0);
let timer = null;

// 发送验证码
const sendCode = async () => {
  if (!formState.value.phone || !/^1[3-9]\d{9}$/.test(formState.value.phone)) {
    message.error("请输入正确的手机号");
    return;
  }

  isSendingCode.value = true;
  countdown.value = 60;

  timer = setInterval(() => {
    if (countdown.value > 0) {
      countdown.value--;
    } else {
      clearInterval(timer);
      isSendingCode.value = false;
    }
  }, 1000);

  try {
    const response = await axios.post("http://localhost/backend/send_sms.php", {
      phone: formState.value.phone,
      userAccount: formState.value.userAccount,
      registerPassword: formState.value.registerPassword,
      confirmPassword: formState.value.confirmPassword,
      code: formState.value.code,
    });
    if (response.data.status === "success") {
      message.success("验证码已发送，请注意查收");
    } else {
      message.error(response.data.message || "验证码发送失败");
      clearInterval(timer);
      isSendingCode.value = false;
    }
  } catch (error) {
    message.error("网络错误，发送失败");
    clearInterval(timer);
    isSendingCode.value = false;
  }
};

// 注册逻辑
const onRegister = async (event) => {
  event.preventDefault();

  const {userAccount, phone, code, registerPassword, confirmPassword} =
      formState.value;

  if (
      !userAccount ||
      !phone ||
      !code ||
      !registerPassword ||
      !confirmPassword
  ) {
    message.error("请填写所有字段");
    return;
  }

  if (registerPassword !== confirmPassword) {
    message.error("密码和确认密码不一致");
    return;
  }

  try {
    const response = await axios.post("http://localhost/backend/register.php", {
      phone: formState.value.phone,
      userAccount: formState.value.userAccount,
      registerPassword: formState.value.registerPassword,
      confirmPassword: formState.value.confirmPassword,
      code: formState.value.code,
    });

    if (response.data.status === "success") {
      message.success("注册成功，请登录");
    } else {
      message.error(response.data.message || "注册失败");
    }
  } catch (error) {
    message.error("网络错误，注册失败");
  }
};
</script>

<style scoped>
.auth-card {

  margin: 50px auto;
}
</style>
