import Mock from 'mockjs';
// 动态生成源数据
Mock.mock("/Mock/chartData", "get", () => {
    const years = ['7月', '8月', '9月', '10月', '11月', '12月'];
    const products = ['娱乐时长', '学习时长', '运动时长', '志愿时长'];

    // 构造动态 source 数据
    const source = [
        ['product', ...years],
        ...products.map(product => [
            product,
            ...Mock.mock({ "array|6": ["@float(20, 100, 1, 1)"] }).array
        ])
    ];

    return {
        code: 200,
        msg: "请求成功",
        source
    };
});