import Mock from 'mockjs';
import usersData from './usersData.json'; // 确保路径正确

// 获取所有用户数据接口
Mock.mock("/Mock/usersData", "get", () => {
    return {
        code: 200,
        msg: "请求数据成功",
        usersData: usersData, // 返回所有用户数据
    };
});

// 按用户名搜索用户接口
Mock.mock(/\/Mock\/getUsersData/, "get", (req) => {
    const urlParams = new URLSearchParams(req.url.split('?')[1]); // 获取查询参数
    const searchName = urlParams.get('username'); // 获取用户名
    let result = usersData;
    if (searchName) {
        result = usersData.filter((user) =>
            user.username.toLowerCase().includes(searchName.toLowerCase()) // 模糊匹配，忽略大小写
        );
    }
    return {
        code: 200,
        msg: "请求数据成功",
        usersData: result, // 返回匹配的用户数据
    };
});

// 删除用户接口
Mock.mock(/\/Mock\/deleteUser\/(\d+)/, "delete", (req) => {
    const id = req.url.split('/').pop(); // 获取 URL 中的 id
    const index = usersData.findIndex(user => user.id === parseInt(id)); // 查找用户在数据中的索引

    if (index !== -1) {
        usersData.splice(index, 1); // 删除用户
        return {
            code: 200,
            msg: "用户删除成功",
        };
    } else {
        return {
            code: 400,
            msg: "用户未找到",
        };
    }
});

