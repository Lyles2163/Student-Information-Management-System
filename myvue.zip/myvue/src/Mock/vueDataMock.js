import Mock from 'mockjs';
import vueData from '../Mock/vueData.json'
Mock.mock('/Mock/vueData', 'get', () => {
    return {
        code: 200,
        message: '成功',
        vueData: vueData,
    };
});