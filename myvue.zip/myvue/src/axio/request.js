import axios from 'axios'
const request = axios.create({
    baseURL: "/", // 确保路径匹配
    timeout: 2000, // 请求超时时间
});
export default request;

