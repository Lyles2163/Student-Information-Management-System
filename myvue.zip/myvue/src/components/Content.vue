<template>
  <a-layout-content
      :style="{ margin: '0', background: getContentBgColor(), position: 'relative' }"
  >
    <!-- 自定义加载图片 -->
    <transition name="fade">
      <div v-if="loading" class="loading-overlay">
        <img src="/assets/media/loading4.gif" class="loading-img" />
      </div>
    </transition>

    <!-- 路由视图 -->
    <router-view></router-view>
  </a-layout-content>
</template>


<script setup>
import { ref, watch } from 'vue';
import { useRouter } from 'vue-router';
import { inject, provide } from 'vue';

// 获取全局主题
const theme = inject('theme');
provide('theme', theme);

// 加载状态
const loading = ref(false);

// 根据主题获取内容区域背景色
const getContentBgColor = () => {
  return theme.value === 'dark' ? '#001033' : '#f9f9f9';
};

// 获取路由实例
const router = useRouter();

// 监听路由变化控制加载状态
watch(
    () => router.currentRoute.value,
    async () => {
      loading.value = true; // 显示加载动画

      setTimeout(() => {
        router.push(router.currentRoute.value.fullPath); // 0.4秒后跳转路由

        // **增加200ms等待渐变效果完成后再关闭加载状态**
        setTimeout(() => {
          loading.value = false; // 渐变动画完成后隐藏
        }, 100); // 渐变消失时长
      }, 100); // 加载延迟时间
    }
);

</script>

<style scoped>
/* 自定义加载图片样式 */
.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgb(255, 255, 255); /* 半透明背景 */
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999; /* 确保在最顶层 */
}

/* 自定义GIF大小 */
.loading-img {
  width: 64px;
  height: 64px;
}

/* 渐变效果 */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease-in-out; /* 渐变动画时长 */
}

.fade-enter,
.fade-leave-to {
  opacity: 0; /* 初始透明度为0 */
}

</style>
