<template>
  <a-layout-footer
      style="text-align: center; height: 40px"
      :style="{ background: getFooterBgColor(), color: getTextColor() }"
      theme="dark"
  >
   计应2305   李阳  期末作业
  </a-layout-footer>
</template>

<script setup>
import { inject } from 'vue';

// 获取全局主题
const theme = inject('theme');

// 动态样式
const getFooterBgColor = () => {
  return theme.value === 'dark' ? '#002c55' : '#017fa8';
};
const getTextColor = () => {
  return theme.value === 'dark' ? '#c5c5c5' : '#000';
};
</script>

<style scoped>
/* Customize footer styles */

</style>
