<template>
  <a-layout style="min-height: 100vh">
    <Sidebar />
    <a-layout>
      <Header />
      <Content />
      <a-switch class="theme-switch"
          :checked="theme === 'dark'"
          checked-children="Dark"
          un-checked-children="Light"
          @change="changeTheme"
          theme="light"
          disabled
      />
      <Footer />
    </a-layout>
  </a-layout>
<!--<UserTable/>-->
</template>

<script setup>
import { ref, provide } from 'vue';
import Header from './Header.vue';
import Sidebar from './Sidebar.vue';
import Footer from './Footer.vue';
import Content from './Content.vue';
import Page2 from "../views/userManagement.vue";
import UserTable from './UserTable.vue'

// 全局主题状态
const theme = ref('light');

// 切换主题的方法
const changeTheme = (checked) => {
  theme.value = checked ? 'dark' : 'light';
};

// 提供全局主题
provide('theme', theme);
</script>

<style scoped>
.theme-switch {display: none;
}
</style>
