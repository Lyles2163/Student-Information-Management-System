<template>
  <!-- 整个页面容器 -->
  <div class="background">
    <!-- 顶部标题区域 -->
    <div class="header-container">
      <h1 class="title">
        <i ref="typingTextRef" class="typing-text">Vue.js</i><br /><br />
        朝阳班班后台管理系统
      </h1>
    </div>

    <!-- 登录表单区域 -->
    <div class="login-container">
      <div class="login-box">
        <!-- 头像区域 -->
        <div class="avatar-box">
          <img
              class="avatar"
              :src="avatarUrl || '/assets/media/LogosRisingwaveIcon.png'"
              alt="头像"
          />
        </div>

        <!-- 登录表单 -->
        <div class="form-login">
          <!-- 用户名输入 -->
          <div class="form-group">
            <label for="username">登录名称</label>
            <input
                type="text"
                class="form-control"
                id="username"
                placeholder="请输入登录名称"
                autocomplete="off"
                v-model.trim="username"
            />
          </div>

          <!-- 密码输入 -->
          <div class="form-group">
            <label for="password">登录密码</label>
            <input
                type="password"
                class="form-control"
                id="password"
                placeholder="请输入登录密码"
                v-model.trim="password"
            />
          </div>

          <!-- 登录按钮 -->
          <div class="form-group">
            <button type="button" class="btn" @click="onLogin">登 录</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import { useUserStore } from "../stores/userStore";
import router from "../router/router.js";

// 响应式变量
const username = ref("");
const password = ref("");
const user = ref([]);
const avatarUrl = ref("");
const typingTextRef = ref(null);

// 获取用户数据
const userStore = useUserStore();
onMounted(async () => {
  await userStore.getUserData();
  user.value = userStore.user;
});

// 监听用户名动态更新头像
watch(username, (newUsername) => {
  const foundUser = user.value.find((u) => u.userAccount === newUsername);
  avatarUrl.value = foundUser?.avatarUrl || "/assets/media/LogosRisingwaveIcon.png";
});

// 登录逻辑
const onLogin = async () => {
  await userStore.login(username.value, password.value);
  await router.push("/home/UserCenter/PersonalInformation");
};

// 打字机效果
const textToType = ref([
  ["加入朝阳班班，开启希望之帆"],
  ["知识曙光初照，成长之路扬帆"],
  ["这里有良师引航，伴你破浪向前"],
  ["与同学携手共进，使梦想不再遥远"]
]);
const currentText = ref("");
const index = ref(0);
const charIndex = ref(0);
const isDeleting = ref(false);

const typeText = () => {
  const word = textToType.value[index.value][0];
  if (!isDeleting.value) {
    if (charIndex.value < word.length) {
      currentText.value += word.charAt(charIndex.value++);
      typingTextRef.value.textContent = currentText.value;
      setTimeout(typeText, 100);
    } else {
      setTimeout(() => {
        isDeleting.value = true;
        setTimeout(deleteText, 1000);
      }, 1000);
    }
  }
};

const deleteText = () => {
  if (charIndex.value > 0) {
    currentText.value = currentText.value.slice(0, -1);
    typingTextRef.value.textContent = currentText.value;
    charIndex.value--;
    setTimeout(deleteText, 50);
  } else {
    isDeleting.value = false;
    currentText.value = "";
    index.value = (index.value + 1) % textToType.value.length;
    setTimeout(typeText, 500);
  }
};

onMounted(() => {
  setTimeout(typeText, 500);
});
</script>

<style lang="less" scoped>
/* 淡入与放大效果 */
@keyframes fadeInScale {
  0% {
    opacity: 0;
    transform: scale(0.9);
  }
  100% {
    opacity: 1;
    transform: scale(1);
  }
}

/* 按钮悬停动画 */
@keyframes pulseGlow {
  0% {
    box-shadow: 0 0 5px rgba(134, 168, 231, 0.6);
  }
  50% {
    box-shadow: 0 0 20px rgba(145, 234, 228, 0.8);
  }
  100% {
    box-shadow: 0 0 5px rgba(134, 168, 231, 0.6);
  }
}

/* 输入框聚焦动画 */
@keyframes inputFocusShake {
  0%, 100% {
    transform: translateX(0);
  }
  25% {
    transform: translateX(2px);
  }
  75% {
    transform: translateX(-2px);
  }
}
/* 登录框整体淡入动画 */
.login-box {
  animation: fadeInScale 1s ease-out; /* 淡入并放大 */
}

/* 输入框聚焦效果 */
.form-control:focus {
  box-shadow: 0 0 10px rgba(145, 234, 228, 0.8);
  animation: inputFocusShake 0.3s ease-in-out;
}

/* 登录按钮悬停动画 */
.btn:hover {
  background: #91eae4;
  transform: translateY(-3px); /* 悬停时上升 */
  animation: pulseGlow 1.5s infinite;
}

/* 背景 */
.background {
  background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

/* 标题区域 */
.header-container {
  text-align: center;
  margin-bottom: 2rem;

  .title {
    font-size: 2.5rem;
    color: #fff;
    text-shadow: 0 0 8px rgba(255, 255, 255, 0.27);
    margin: 0;

    .typing-text {
      font-size: 3rem;
      font-weight: bold;
      background-image: linear-gradient(
          90deg,
          #ff7e5f,
          #feb47b,
          #86a8e7,
          #91eae4
      );
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      animation: hue-rotate 3s infinite;
    }
  }
}

@keyframes hue-rotate {
  from {
    filter: hue-rotate(0deg);
  }
  to {
    filter: hue-rotate(360deg);
  }
}

/* 登录框 */
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
}

.login-box {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  padding: 2rem;
  border-radius: 15px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
  text-align: center;
  width: 400px;
}

/* 头像区域 */
.avatar-box {
  margin: -60px auto 20px;
  width: 120px;
  height: 120px;

  .avatar {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    border: 5px solid #fff;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.4);
  }
}

/* 表单 */
.form-group {
  margin-bottom: 1.5rem;
  text-align: left;

  label {
    color: #fff;
    font-size: 1rem;
  }

  .form-control {
    width: 100%;
    padding: 0.7rem;
    border: none;
    border-radius: 5px;
    outline: none;
    transition: all 0.3s;
  }

  .form-control:focus {
    box-shadow: 0 0 8px #91eae4;
  }

  .btn {
    background: #86a8e7;
    color: white;
    border: none;
    padding: 0.7rem;
    width: 100%;
    border-radius: 5px;
    cursor: pointer;
    transition: background 0.3s ease;
  }

  .btn:hover {
    background: #91eae4;
  }
}
</style>
