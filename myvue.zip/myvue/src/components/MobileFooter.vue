<template>
  <div>
    <div class="custom-tabbar">
      <div
          v-for="(tab, index) in tabs"
          :key="index"
          class="custom-tabbar-item"
          :class="{ active: $route.path === tab.path }"
          @click.prevent="onTabClick(tab.path)"
      >
        <img :src="tab.icon" class="icon" :class="{ active: $route.path === tab.path }" />
        <h6 class="label">{{ tab.label }}</h6>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter, useRoute } from "vue-router";

const router = useRouter();
const route = useRoute();

const tabs = [
  { label: "首页", icon: "/assets/icon/home.png", path: "/MobileHome/MobileContent/MobileIndex" },
  { label: "消息", icon: "/assets/icon/message.png", path: "/MobileHome/MobileContent/MobileMessage" },
  { label: "发布", icon: "/assets/icon/addButton.png", path: "/MobileHome/MobileContent/MobileAnnounce" },
  { label: "班级", icon: "/assets/icon/friend.png", path: "/MobileHome/MobileContent/MobileClassMate" },
  { label: "我的", icon: "/assets/icon/me.png", path: "/MobileHome/MobileContent/MobilePersonage" },
];

function onTabClick(path) {
  router.push(path); // 确保路由跳转
}
</script>

<style scoped>
/* 自定义底部导航栏容器 */
.custom-tabbar {
  display: flex;
  justify-content: space-around;
  align-items: center;
  background: #f8f8f8;
  border-top: 1px solid #ddd;
  position: fixed;
  bottom: 0;
  width: 100%;
  height: 60px;
  z-index: 100;
}

/* 每个 Tab 的样式 */
.custom-tabbar-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #999;
  cursor: pointer;
}

/* 图标样式 */
.custom-tabbar-item .icon {
  width: 24px;
  height: 24px;
  margin-bottom: 4px;
  transition: filter 0.3s, transform 0.2s;
}

/* 激活状态的样式（整体变蓝） */
.custom-tabbar-item .icon.active {
  filter: brightness(0) saturate(100%) invert(33%) sepia(79%) saturate(2413%) hue-rotate(201deg) brightness(93%) contrast(96%);
  transform: scale(1.05); /* 可选：稍微放大效果 */
}

.custom-tabbar-item .label {
  transition: color 0.3s;
}

.custom-tabbar-item.active .label {
  color: #1d92ff;
}
</style>
