<template>
  <div style="background:rgba(29,145,253,0)" class="top-bar">
    <!-- 左侧部分 -->
    <div class="left-section">
      <span class="time">{{ currentTime }}</span>
      <img style="margin-right: 2px" src="/assets/icon/AntDesignBilibiliFilled.png" alt="Setting Icon" class="icon" />
      <img style="width: 19px ;margin-right: 4px" src="/assets/icon/BiAlipay.png" alt="Setting Icon" class="icon" />
      <img style="width: 19px ;margin-right: 4px" src="/assets/icon/SimpleIconsMeituan.png" alt="Setting Icon" class="icon" />
    </div>

    <!-- 中间部分 -->
    <div class="middle-section">
    </div>

    <!-- 右侧部分 -->
    <div class="right-section">
      <img style="width: 20px;height:20px;margin: 1px" src="/assets/icon/MdiNfc.png" alt="Setting Icon" />
      <img style="width: 20px;height:20px;margin: 1px" src="/assets/icon/IconoirSoundMinSolid.png" alt="Setting Icon" />
      <img style="width: 20px;height:20px;margin: 1px" src="/assets/icon/HumbleiconsWifi.png" alt="Wi-Fi Icon" />
      <img style="width: 20px;height:20px;margin: 1px" src="/assets/icon/FluentCellular5g24Filled.png" alt="Bell Icon" />
      <img style="width: 20px;height:20px;margin: 1px" src="/assets/icon/MaterialSymbolsBatteryHoriz050.png" alt="Battery Icon" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from "vue";

const currentTime = ref("");

const updateCurrentTime = () => {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  currentTime.value = `${hours}:${minutes}`;
};

onMounted(() => {
  updateCurrentTime();
  const interval = setInterval(updateCurrentTime, 1000); // 每秒更新
  onUnmounted(() => clearInterval(interval)); // 组件卸载时清除定时器
});
</script>

<style scoped>
/* 顶部栏样式 */
.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2px;
}

/* 左侧部分 */
.left-section {
  display: flex;
  flex-direction: row;
}

.greeting {
  font-size: 16px;
  font-weight: bold;
}

.date {
  font-size: 14px;
  color: #999;
  margin-top: 4px;
}

/* 中间部分 */
.middle-section {
  display: flex;
  align-items: center;
}

.icon {
  width: 24px;
  height: 24px;
  object-fit: contain;
}

/* 右侧部分 */
.right-section {
  display: flex;
  align-items: center;
}

.time {
  font-size: 12px;
  margin-right: 10px;
  align-self: center;
}

.right-section .icon {
  margin-left: 10px;
}
</style>
