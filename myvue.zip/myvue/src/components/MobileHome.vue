<script setup>
import MobileHeader from "./MobileHeader.vue";
import MobileFooter from "./MobileFooter.vue";
import MobileContent from "./MobileContent.vue";
</script>

<template>
  <MobileHeader></MobileHeader>
  <MobileContent></MobileContent>
  <MobileFooter></MobileFooter>
</template>

<style scoped>

</style>