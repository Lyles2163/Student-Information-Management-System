<!-- LoginRegister.vue -->
<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";

const router = useRouter();
const activeKey = ref("/MobileLogin/MobileLoginForm");

// 切换 Tab 时触发
const onTabChange = (key) => {
  activeKey.value = key;
  router.push(key); // 跳转路由
};
</script>

<template>
  <div class="background">
    <div class="header-container">
      <h1 class="title">朝阳班班</h1>
    </div>

    <!-- Tabs 切换栏 -->
    <div class="login-container">
      <div class="login-box">
        <a-tabs v-model:activeKey="activeKey" @change="onTabChange" centered>
          <a-tab-pane key="/MobileLogin/MobileLoginForm" tab="登录" />
          <a-tab-pane key="/MobileLogin/MobileRegisterForm" tab="注册" />
        </a-tabs>

        <!-- 路由视图 -->
        <router-view />
      </div>
    </div>
  </div>
</template>

<style scoped>
/* 背景样式 */
.background {
  background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.header-container {
  text-align: center;
  margin-bottom: 2rem;
}

.title {
  font-size: 2.5rem;
  color: #fff;
  text-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
}

.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
}

.login-box {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  padding: 2rem;
  border-radius: 15px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
  width: 400px;
  text-align: center;
}
</style>
