<template>
  <a-layout-sider
      v-model:collapsed="collapsed"
      collapsible
      :style="{ background: getSidebarBgColor(), color: getTextColor() }"
  >
    <div class="logo2">
      <img
          src="/assets/media/LogosRisingwaveIcon.png"
          :style="getIconStyle()"
      />
    </div>

    <!-- 菜单 -->
    <a-menu
        :openKeys="openKeys"
        :selectedKeys="selectedKeys"
        @openChange="handleOpenChange"
        @select="handleSelect"
        mode="inline"
        :theme="menuTheme"
        :style="{ width: collapsed ? '80px' : '200px' }"
    >
      <template v-for="item in menuItemsWithRoutes">
        <a-menu-item
            v-if="!item.children"
            :key="'menuitem-' + item.key"
            :icon="item.icon"
            :disabled="item.disabled"
            @click="handleMenuClick(item)"
        >
          <a-spin :spinning="loading && currentMenuKey === item.key" :indicator="customLoadingIndicator">
            {{ item.label }}
          </a-spin>
        </a-menu-item>

        <a-sub-menu
            v-else
            :key="'submenu-' + item.key"
            :title="item.label"
            :icon="item.icon"
        >
          <a-menu-item
              v-for="child in item.children"
              :key="'menuitem-child-' + child.key"
              :icon="child.icon"
              :disabled="child.disabled"
              @click="handleMenuClick(child)"
          >
            <a-spin :spinning="loading && currentMenuKey === child.key" :indicator="customLoadingIndicator">
              {{ child.label }}
            </a-spin>
          </a-menu-item>
        </a-sub-menu>
      </template>
    </a-menu>
  </a-layout-sider>
</template>


<script setup>
import { ref, computed, h, inject, watch } from 'vue';
import { useRouter } from 'vue-router';
import { message } from 'ant-design-vue';
import {
  MailOutlined,
  CalendarOutlined,
  AppstoreOutlined,
  SettingOutlined,
  UserOutlined,
} from '@ant-design/icons-vue';

const loading = ref(false); // 控制加载状态
const currentMenuKey = ref(''); // 当前菜单项 key
const router = useRouter();
const collapsed = ref(false);
const openKeys = ref(['sub1']);
const selectedKeys = ref(['1']);

// 用户角色
const currentUserRole = ref(localStorage.getItem('currentUserRole'));

// 监听 localStorage 的变化
window.addEventListener('storage', () => {
  currentUserRole.value = localStorage.getItem('currentUserRole');
});

// **注入全局主题**
const theme = inject('theme');

// 菜单数据
const items = ref([
  { key: '1', icon: () => h(UserOutlined), label: '班级首页', route: '/home/backstageIndex', disabled: false },
  { key: '2', icon: () => h(CalendarOutlined), label: '用户管理', route: '/home/UserManagementPage', disabled: false },
  { key: '5', icon: () => h(CalendarOutlined), label: '信息管理', route: '/home/InformationManagement', disabled: false },
  {
    key: 'sub1',
    icon: () => h(AppstoreOutlined),
    label: '个人中心',
    children: [
      { key: '4', icon: () => h(CalendarOutlined), label: '个人介绍', route: '/home/UserCenter/PersonalInformation', disabled: false },
      { key: '3', icon: () => h(MailOutlined), label: '个人设置', route: '/home/UserCenter/PersonalSet', disabled: false },
    ],
  },
  { key: 'sub2', icon: () => h(SettingOutlined), label: '页面4', route: '/home/SettingPage', disabled: false },
]);

// 菜单项数据
const menuItemsWithRoutes = computed(() =>
    items.value.map((item) => ({
      ...item,
      children: item.children?.map((child) => ({
        ...child,
      })),
    }))
);

// 路由跳转方法
const navigate = (route) => {
  router.push(route);
};

// 自定义加载指示器（GIF）
const customLoadingIndicator = h('img', {
  src: '/assets/media/loading.gif',  // 你的自定义GIF路径
  style: {
    width: '20px',
    height: '20px',
    marginRight: '8px',
  },
});

// 菜单点击处理
const handleMenuClick = (item) => {
  const checkAdminAccess = (key) => {
    if (currentUserRole.value !== '1') {
      message.error('您不是管理员，不能操作此页面');
      const targetItem = items.value.find((menu) => menu.key === key);
      if (targetItem) targetItem.disabled = true;
      return false; // 禁止继续操作
    }
    return true; // 允许继续操作
  };

  const switchRoute = () => {
    loading.value = true; // 启用加载状态

    // **延迟0.4秒后跳转路由**
    setTimeout(() => {
      navigate(item.route); // 执行跳转
      setTimeout(() => {
        loading.value = false; // 跳转后关闭加载状态
      }, 100); // 确保跳转后再隐藏加载动画
    }, 100); // 延迟0.4秒
  };

  if (item.key === '2' || item.key === '5') {
    // 检查管理员权限
    if (checkAdminAccess(item.key)) {
      message.success('欢迎您，管理员');
      switchRoute(); // 加载后跳转
    }
  } else {
    switchRoute(); // 加载后跳转
  }
};


// 菜单事件处理
const handleOpenChange = (keys) => {
  openKeys.value = keys;
};

const handleSelect = ({ key }) => {
  selectedKeys.value = [key];
};

// 样式
const getSidebarBgColor = () => (theme.value === 'dark' ? '#002c55' : '#ffffff');
const getTextColor = () => (theme.value === 'dark' ? '#c5c5c5' : '#000');
const menuTheme = computed(() => (theme.value === 'dark' ? 'dark' : 'light'));

// 图标样式
const getIconStyle = () => ({
  height: '64px',
  color: theme.value === 'dark' ? '#003061' : '#0185ff',
  backgroundColor: theme.value === 'dark' ? '#005cdf' : '#00bdfa',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
});
</script>


<style scoped>
/* 调整图标与文字间距 */
a-menu-item .anticon {
  font-size: 16px;
  margin-right: 10px;
}

/* 调整菜单项文字大小 */
a-menu-item {
  font-size: 14px;
}

/* 折叠时隐藏菜单文字 */
a-layout-sider.collapsed .ant-menu-item span {
  display: none;
}

/* 折叠时调整图标大小 */
a-layout-sider.collapsed .ant-menu-item .anticon {
  font-size: 14px;
}

/* 自定义加载动画的样式 */
.custom-loading-icon {
  width: 20px;
  height: 20px;
  margin-right: 8px;
  vertical-align: middle;
}

.ant-layout-sider-trigger {
  background: #fff;
}

</style>
