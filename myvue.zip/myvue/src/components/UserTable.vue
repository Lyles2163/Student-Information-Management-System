<template>
  <div style="display: flex; justify-content: center;  ">
    <div style=" width: 98% ;box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
      <!-- 表格 -->
      <a-table

          :columns="[
          { title: 'ID', dataIndex: 'id', className: 'custom-header' },
          { title: '用户名', dataIndex: 'username',className: 'custom-header'  },
          { title: '头像', dataIndex: 'avatarUrl' ,className: 'custom-header' },
          { title: '账号', dataIndex: 'userAccount',className: 'custom-header'  },
          { title: '密码', dataIndex: 'userPassword',className: 'custom-header'  },
          { title: '性别', dataIndex: 'gender',className: 'custom-header'  },
          { title: '年龄', dataIndex: 'age',className: 'custom-header'  },
          { title: '用户角色', dataIndex: 'userRole',className: 'custom-header'  },
          { title: '操作', key: 'action',className: 'custom-header'  },
        ]"
          :data-source="user"
          :pagination="{
          current: currentPage,
          pageSize: pageSize,
          total: total,
          showSizeChanger: true,
        }"
          @change="handlePageChange"

      >
        <template #bodyCell="{ column, record }">
          <template v-if="column.dataIndex === 'username'" >
            <div >{{ record.username }}</div>
          </template>
          <template v-else-if="column.dataIndex === 'userRole'">
            <div v-if="record.userRole === 1">
              <a-tag color="red">管理员</a-tag>
            </div>
            <div v-if="record.userRole === 0">
              <a-tag color="blue">普通用户</a-tag>
            </div>
            <div v-if="record.userRole === 3">
              <a-tag color="gold">双创委员</a-tag>
            </div>
            <div v-if="record.userRole === 4">
              <a-tag color="gold">伍班班长</a-tag>
            </div>
            <div v-if="record.userRole === 4">
              <a-tag color="gold">反诈委员</a-tag>
            </div>
            <div v-if="record.userRole === 5">
              <a-tag color="gold">学习委员</a-tag>
            </div>
            <div v-if="record.userRole === 6">
              <a-tag color="gold">副班长</a-tag>
            </div>
            <div v-if="record.userRole === 7">
              <a-tag color="gold">宣传委员</a-tag>
            </div>
            <div v-if="record.userRole === 8">
              <a-tag color="gold">团支书</a-tag>
            </div>
            <div v-if="record.userRole === 9">
              <a-tag color="gold">副团支书</a-tag>
            </div>
            <div v-if="record.userRole === 10">
              <a-tag color="gold">体育委员</a-tag>
            </div>
            <div v-if="record.userRole === 11">
              <a-tag color="gold">组织委员</a-tag>
            </div>
            <div v-if="record.userRole === 12">
              <a-tag color="gold">劳动委员</a-tag>
            </div>
            <div v-if="record.userRole === 12">
              <a-tag color="gold">生活委员</a-tag>
            </div>
            <div v-if="record.userRole === 13">
              <a-tag color="gold">心理委员</a-tag>
            </div>
          </template>
          <template v-else-if="column.dataIndex === 'avatarUrl'">
            <a-image :src="record.avatarUrl" :width="50" :height="50" style="border-radius: 6px"/>
          </template>
          <template v-else-if="column.dataIndex === 'createTime'">
            {{ dayjs(record.createTime).format('YYYY-MM-DD') }}
          </template>
          <template v-else-if="column.key === 'action'" >
            <!-- 确认删除弹框 -->
            <popconfirm
                title="确认删除该用户?"
                @confirm="() => deleteUser(record.id)"
            >
              <a-button type="primary" danger>删除</a-button>
            </popconfirm>
            <a-button type="primary" @click="editUser(record.id)">编辑</a-button>
          </template>
          <template v-else-if="column.dataIndex === 'createTime'">
            {{ dayjs(record.createTime).format("YYYY-MM-DD") }}
          </template>
          <template v-else>
            {{ record[column.dataIndex] }}
          </template>
        </template>
      </a-table>

    </div>
  </div>
</template>

<script setup>
// import { ref, onMounted } from 'vue';
import axios from 'axios';
import { inject, onMounted, reactive, ref } from "vue";
import {
  message,
  Popconfirm,

  ConfigProvider,
} from "ant-design-vue";
import dayjs from "dayjs";
import zhCN from "ant-design-vue/es/locale/zh_CN";
import request from "../axio/request.js";

// 获取全局主题
const theme = inject("theme");
const searchValue = ref(""); // 搜索框的值

// 表格数据相关
const data = ref([]);
const currentPage = ref(1); // 当前页码
const pageSize = ref(9); // 每页显示条数
const total = ref(0); // 总条数

const isModalVisible = ref(false); // 控制弹窗显示
const isEditMode = ref(false); // 是否是编辑模式
const userForm = reactive({
  id: null,
  username: "",
  avatarUrl: "",
  userAccount: "",
  userPassword: "",
  gender: "男",
  age: null,
  userRole: 0,
});
const user = ref([]);

// 在组件加载时调用接口获取用户数据
onMounted(async () => {
  try {
    const response = await axios.get('http://localhost/backend/fetch_users.php');
    user.value = response.data; // 设置获取到的数据
  } catch (error) {
    console.error('Error fetching user data:', error);
  }
});
</script>

<style scoped>
/* 可以在这里添加样式 */
</style>
