// main.js
import { createApp } from 'vue';
import App from './App.vue'; // 引入根组件
import './Mock/mockServer.js';

import './Mock/vueDataMock.js'
// 全局样式
import './style.css';


import Particles from 'particles.vue3';

// 路由配置
import router from './router/router.js';

// 状态管理
import { createPinia } from 'pinia';
const pinia = createPinia();

// Ant Design Vue
import Antd from 'ant-design-vue';
import 'ant-design-vue/dist/reset.css';



// Vant
import Vant from 'vant';
import 'vant/lib/index.css';

// Element Plus
import ElementPlus from 'element-plus';
import 'element-plus/dist/index.css';
import * as ElementPlusIconsVue from '@element-plus/icons-vue';

// 兼容性处理
import 'core-js/stable';
import 'regenerator-runtime/runtime';

// 创建 Vue 应用实例
const app = createApp(App);


// 配置插件
app.use(router); // 注册路由
app.use(pinia); // 注册 Pinia
app.use(Antd); // 注册 Ant Design Vue
app.use(ElementPlus); // 注册 Element Plus
app.use(Vant);
app.use(Particles);
// 注册 Element Plus 图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
    app.component(key, component);
}

// 配置全局属性或方法
app.config.globalProperties.$showMessage = function (message) {
    console.log(message);
};

// 挂载应用到 DOM
app.mount('#app');
