import {createRouter, createWebHashHistory} from 'vue-router';
import {h} from 'vue';

// 导入各个页面组件
import Loginpage from '../components/Loginpage.vue';
import Homepage from '../components/Homepage.vue';
import backstageIndex from '../views/index.vue';
import UserManagementPage from '../views/userManagement.vue';
import UserCenter from '../views/UserCenter.vue';
import InformationManagement from '../views/InformationManagement.vue';
import Subpage1 from '../views/UserCenter/Subpage1.vue';
import Subpage2 from '../views/UserCenter/Subpage2.vue';
import SettingPage from '../views/SettingPage.vue';
import MobileHome from "../components/MobileHome.vue";
import MoblieContent from "../components/MobileContent.vue";
import MobileIndex from "../MoblieViews/MobileIndex.vue";
import MobileMessage from "../MoblieViews/MoblieMessage.vue";
import MobileAnnounce from "../MoblieViews/MobileAnnounce.vue";
import MobileClassMate from "../MoblieViews/MobileClassMate.vue";
import MobilePersonage from "../MoblieViews/MobliePersonage.vue";
import MobileLogin from "../components/MobileLogin.vue";
import MobileActivities from "../MoblieViews/MobileIndex/MobileActivities.vue";
import MobileAssignments from "../MoblieViews/MobileIndex/MobileAssignments.vue";
import MobileDynamic from "../MoblieViews/MobileIndex/MobileDynamic.vue"
import MobileNotifications from "../MoblieViews/MobileIndex/MobileNotifications.vue"
import NotFound from '../views/NotFound.vue';  // 404 页面

const router = createRouter({
    history: createWebHashHistory(),
    routes: [
        {path: '/', redirect: '/login'},  // 默认重定向到登录页面
        {path: '/login', component: Loginpage},  // 登录页面
        {
            path: '/home',
            component: Homepage,
            redirect: '/home/backstageIndex',  // 默认重定向到子路由 page1
            children: [
                {path: 'backstageIndex', component: backstageIndex},
                {path: 'UserManagementPage', component: UserManagementPage},
                {path: 'InformationManagement', component: InformationManagement},
                {
                    path: 'UserCenter',
                    component: UserCenter,
                    children: [
                        {path: 'PersonalSet', component: Subpage1},
                        {path: 'PersonalInformation', component: Subpage2},
                    ]
                },
                {path: 'SettingPage', component: SettingPage}
            ]
        },
        // 404 页面
        {
            path: '/:pathMatch(.*)*',
            component: NotFound
        },
        {
            path: '/MobileLogin',
            component: MobileLogin,
            redirect: '/MobileLogin/MobileLoginForm',
            children: [
                {path: 'MobileRegisterForm', component: () => import('../MoblieViews/mobileLogin/RegisterForm.vue')},
                {path: 'MobileLoginForm', component: () => import('../MoblieViews/mobileLogin/LoginForm.vue')},
            ]
},
        {
            path: '/MobileHome', component: MobileHome, children: [
                {
                    path: '/MobileHome/MobileContent', component: MoblieContent,
                    redirect: '/MobileHome/MobileContent/MobileIndex',
                    children: [
                        {
                            path: "MobileIndex", component: MobileIndex,
                            redirect: '/MobileHome/MobileContent/MobileIndex/MobileDynamic',
                            children: [
                                {path: "MobileActivities", component: MobileActivities},
                                {path: "MobileAssignments", component: MobileAssignments},
                                {path: "MobileDynamic", component: MobileDynamic},
                                {path: "MobileNotifications", component: MobileNotifications},
                            ]
                        },
                        {path: "MobileMessage", component: MobileMessage},
                        {path: "MobileAnnounce", component: MobileAnnounce},
                        {path: "MobileClassMate", component: MobileClassMate},
                        {path: "MobilePersonage", component: MobilePersonage},]
                },
            ]
        },
    ]
});

// 全局前置路由守卫
router.beforeEach((to, from, next) => {
    // 获取Token值
    const token = localStorage.getItem('token');

    // 如果是访问登录页，直接放行
    if (to.path === '/login') {
        return next();
    }

    // 如果没有token且不是去登录页，重定向到登录页并传递当前要访问的路径作为查询参数
    if (!token && to.path !== '/login') {
        return next({path: '/login', query: {redirect: to.fullPath}});
    }

    // 其他情况正常放行
    next();
});

export default router;
