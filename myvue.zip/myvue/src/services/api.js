import axios from 'axios';

// 配置 axios 实例
const api = axios.create({
    baseURL: 'http://localhost:3000', // 后端接口的基本 URL
    timeout: 5000, // 请求超时时间
});

// 获取用户数据
export const getUsersDataOne = () => {
    return api.get('/Mock/usersData') // 请求接口
        .then(response => {
            if (response.data.code === 200) {
                return response.data.usersData;
            } else {
                throw new Error('获取数据失败');
            }
        })
        .catch(error => {
            console.error("请求失败:", error);
            throw error; // 抛出错误以便后续处理
        });
};
