import { defineStore } from 'pinia';
import axios from 'axios';
import { ref } from "vue";

export const CourseDurationStore = defineStore('CourseDurationStore', () => {
    // 定义 state
    const id = ref('');  // 使用 ref 包装单一值
    const xAxisData = ref([]);  // x 轴分类数据
    const seriesData = ref([]);  // 各系列数据
    const currentUserID = ref(localStorage.getItem("userID")); // 从 localStorage 获取用户 ID

    // 定义 action
    const fetchChartData = async () => {
        try {
            // 获取当前用户 ID
            const currentUserID = localStorage.getItem("userID");
            if (!currentUserID) {
                console.error('用户 ID 为空，无法获取数据');
                return;
            }

            // 请求数据
            const response = await axios.get('/Mock/CourseDurationData');
            console.log(response); // 查看响应的数据

            if (response.data && response.data.length > 0) {
                // 将用户 ID 转为数字以匹配数据格式
                const userID = parseInt(currentUserID, 10);

                // 查找与当前用户 ID 匹配的数据
                const userData = response.data.find(data => data.id === userID);

                if (userData) {
                    id.value = userData.id;
                    xAxisData.value = userData.xAxisData;
                    seriesData.value = userData.seriesData;
                } else {
                    console.error(`未找到用户 ID 为 ${userID} 的数据`);
                }
            } else {
                console.error('数据加载失败或数据为空');
            }
        } catch (error) {
            console.error('请求错误', error);
        }
    };


    // 使用 return 返回 state 和 actions
    return {
        id,
        xAxisData,
        seriesData,
        currentUserID,
        fetchChartData,
    };
});
