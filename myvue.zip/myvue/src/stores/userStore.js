import { defineStore } from "pinia";
import { ref } from "vue";
import request from "../axio/request";
import { message } from "ant-design-vue";
import router from "../router/router.js";



export const useUserStore = defineStore("userStore", () => {
    const user = ref([]);
    const userData=ref([]);
    const userInfo = ref({});
    const timeData = ref([]);
    const userID=ref("userID"||"");
    const currentUsername = ref(localStorage.getItem("currentUsername") || ""); // 从 localStorage 获取
    const avatarUrl = ref(localStorage.getItem("avatarUrl") || ""); // 从 localStorage 获取头像 URL
    const userSex=ref(localStorage.getItem("userSex")||"");
    const currentUserRole=ref(localStorage.getItem("currentUserRole")||"");
    const currentUserID=ref(localStorage.getItem("currentUserID")||"");



    const fetchUserData = async () => {
        try {
            const response = await request({
                url: "http://localhost/backend/fetch_users.php",
                method: "get",
            });

            if (response.data) {
                userData.value = response.data; // 更新数据
                // message.success("用户数据加载成功！");
            } else {
                message.warning("用户数据为空！");
            }
        } catch (error) {
            console.error("获取用户数据失败", error);
            message.error("无法加载用户数据，请稍后重试！");
        }
    };


    const getUserInfo = async (userID) => {
        try {
            const response = await request.get(`/backend/get_user_info.php?userID=${userID}`);
            if (response.data.code === 200) {
                userInfo.value = response.data.data;
            } else {
                message.error(response.data.message || "获取用户信息失败");
            }
        } catch (error) {
            message.error("请求失败，请稍后再试！");
        }
    };
    const getUserData = async () => {
        try {
            const res = await request({
                url: "/Mock/usersData",
                method: "get",
            });
            if (res.data.code === 200 && Array.isArray(res.data.usersData)) {
                user.value = res.data.usersData;
            } else {
                message.error("数据格式错误或无数据");
            }
        } catch (error) {
            message.error("请求失败");
        }
    };
    const updateUserInfo = async (updatedInfo) => {
        try {
            const response = await request.post("http://localhost/backend/update_user_info.php", updatedInfo);
            if (response.data.code === 200) {
                // message.success("用户信息更新成功！");
                userInfo.value = { ...userInfo.value, ...updatedInfo };
            } else {
                message.error(response.data.message || "用户信息更新失败！");
            }
        } catch (error) {
            message.error("请求失败，请稍后再试！");
        }
    };
   const getTimeData = async () => {
        try {
            const res = await request({
                url: "/Mock/timeData",
                method: "get",
            });
            if (res.data.code === 200 && Array.isArray(res.data.timeData)) {
                timeData.value = res.data.timeData;
            } else {
                message.error("数据格式错误或无数据");
            }
        } catch (error) {
            message.error("请求失败");
        }
    };
    const login = async (username, password) => {
        if (!username || !password) {
            message.warning("用户名或密码不能为空！");
            return { success: false, message: "用户名或密码不能为空" };
        }

        try {
            const res = await request({
                url: "http://localhost/backend/login.php",
                method: "post",
                data: { username, password },
                withCredentials: true, // 必须添加这行代码
            });

            const data = res.data;

            if (data.code === 200) {
                // 更新状态
                userID.value = data.data.id;
                currentUsername.value = data.data.username;
                avatarUrl.value = data.data.avatarUrl;
                userSex.value = data.data.gender;
                currentUserRole.value = data.data.userRole;

                // 更新 localStorage
                localStorage.setItem("token", "登录成功");
                localStorage.setItem("userID", data.data.id);
                localStorage.setItem("currentUsername", data.data.username);
                localStorage.setItem("avatarUrl", data.data.avatarUrl);
                localStorage.setItem("userSex", data.data.gender);
                localStorage.setItem("currentUserRole", data.data.userRole);

                message.success(`欢迎回来，${data.data.username}`);

                return { success: true };
            } else {
                message.error(data.message || "登录失败！");
                return { success: false, message: data.message || "登录失败！" };
            }
        } catch (error) {
            console.error("登录请求失败", error);
            message.error("服务器错误，请稍后重试！");
            return { success: false, message: "服务器错误，请稍后重试！" };
        }
    };

    const logout = () => {
        // 清除 localStorage 中的用户数据
        localStorage.removeItem("currentUsername");
        localStorage.removeItem("avatarUrl");
        localStorage.removeItem("userSex");
        localStorage.removeItem("currentUserRole");
        localStorage.removeItem("userID");
        localStorage.removeItem("currentUserID")




        const currentUsername = localStorage.getItem("currentUsername") ||""; // 从 localStorage 获取
        const avatarUrl = localStorage.getItem("") //
        const userSex = localStorage.getItem("userSex") || ""; //
        const currentUserRole = localStorage.getItem("currentUserRole") || "";
        const currentUserID = localStorage.getItem("currentUserID") || "";
        const  userID=localStorage.getItem("userID")||"";
        message.info("已退出登录");
            router.push("/login");
        localStorage.removeItem("token");
    };

    return {
        user,
        userData,
        userInfo,
        timeData,
        userID,
        currentUsername,
        avatarUrl,
        userSex,
        currentUserRole,
        currentUserID,
        fetchUserData,
        getUserInfo,
        updateUserInfo,
        getUserData,
        getTimeData,
        login,
        logout,
    };
});
