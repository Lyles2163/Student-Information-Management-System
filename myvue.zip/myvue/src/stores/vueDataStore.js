import { defineStore } from 'pinia';
import axios from 'axios';
import { ref, watch } from 'vue';

export const useVueDataStore = defineStore('vueDataStore', () => {
    const vueId = ref(localStorage.getItem('userID') || ''); // 从本地存储获取 userID
    const vueData = ref([]); // 存储匹配的 vueData 值
    const mysqlData = ref([]); // 存储匹配的 Data 值
    const phpData = ref([]);
    const javaData = ref([]);
    const learnTime = ref([]);



    const getVueData = async () => {
        if (!vueId.value) {
            vueData.value = []; // 如果 vueId 为空，清空数据
            mysqlData.value = [];
            phpData.value = [];
            javaData.value = [];
            learnTime.value=[];

            vueId.value=localStorage.getItem("userID")
            console.log('vueId 为空，未请求数据');
            return;
        }
        try {
            const response = await axios.get('/Mock/vueData');
            const allData = response.data.vueData;

            // 根据 id 过滤出匹配的条目
            const matchedItem = allData.find(item => item.id === parseInt(vueId.value, 10));
            if (matchedItem) {
                vueData.value = matchedItem.vueData; // 保存匹配的 vueData
                mysqlData.value = matchedItem.mysqlData; // 保存匹配的 vueData
                phpData.value = matchedItem.phpData;
                javaData.value=matchedItem.javaData;
                learnTime.value=matchedItem.learnTime;





            } else {
                console.warn('未找到匹配的数据');
                vueData.value = []; // 如果没有匹配，清空数据
                mysqlData.value = [];
                phpData.value = [];
                javaData.value=[];
                learnTime.value=[];


            }
        } catch (error) {
            console.error('获取数据时出错：', error);
        }
    };

    const setVueId = (newId) => {
        // 更新 vueId 并写入 localStorage
        vueId.value = newId;
        localStorage.setItem('userID', newId);
        console.log(`vueId 已更新为 ${newId}`);
    };

    const logout = () => {
        // 清空本地存储的 userID，并重置 vueId
        localStorage.removeItem('userID');
        vueId.value = ''; // 触发 watch 来清空数据
        console.log('用户已退出登录');
    };

    // 监听 vueId 的变化
    watch(
        vueId,
        (newId, oldId) => {
            console.log(`检测到 vueId 从 ${oldId} 变为 ${newId}`);
            getVueData(); // 根据新 vueId 加载数据
        },
        { immediate: true } // 初始化时立即执行一次
    );

    return {
        vueId,
        vueData,
        mysqlData,
        phpData,
        javaData,
        learnTime,
        getVueData,
        setVueId,
        logout,
    };
});
