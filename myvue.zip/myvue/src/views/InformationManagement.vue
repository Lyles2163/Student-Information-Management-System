<template>
  <a-card title="数据展示" style="width: 90%; margin: 20px auto;">
    <!-- Tab 标签页 -->
    <a-tabs v-model:activeKey="activeKey" @change="fetchData">
      <a-tab-pane key="dynamic" tab="用户动态" />
      <a-tab-pane key="event" tab="用户活动" />
      <a-tab-pane key="homework" tab="用户作业" />
      <a-tab-pane key="notification" tab="用户通知" />
    </a-tabs>

    <!-- 数据表格 -->
    <a-table :dataSource="dataList" :columns="columns" :rowKey="idField">
      <template #bodyCell="{ column, record }">
        <!-- 头像列 -->
        <template v-if="column.dataIndex === 'avatarUrl'">
          <a-image
              :src="record.avatarUrl"
              :width="50"
              :height="50"
              style="border-radius: 6px"
          />
        </template>
        <!-- 图片列 -->
        <template v-else-if="column.dataIndex === 'imageUrl'">
          <div v-if="record.imageUrls">
            <a-image
                v-for="(url, index) in parseImageUrls(record.imageUrls)"
                :key="index"
                :src="url"
                :width="50"
                :height="50"
                style="border-radius: 6px; margin-right: 5px"
            />
          </div>
          <span v-else>无图片</span>
        </template>
        <template v-else-if="column.dataIndex === 'title'">
          <div v-if="record.title">
            <p> {{ record.title.length > 7 ? record.title.slice(0, 7) + '...' : record.title }}</p>
          </div>
        </template>
        <template v-else-if="column.dataIndex === 'content'">
          <div v-if="record.content">
            <p> {{ record.content.length > 5 ? record.content.slice(0, 5) + '...' : record.content }}</p>
          </div>
        </template>

        <!-- 操作按钮列 -->
        <template v-else-if="column.dataIndex === 'action'">
          <a-space>
            <!-- 查看按钮 -->
            <a-button type="primary" @click="viewRecord(record)">查看</a-button>
            <!-- 删除按钮，带确认框 -->
            <a-popconfirm
                title="确认删除这条记录吗？"
                ok-text="确定"
                cancel-text="取消"
                @confirm="deleteRecord(record)"
            >
              <a-button type="primary" danger>删除</a-button>
            </a-popconfirm>
          </a-space>
        </template>
      </template>
    </a-table>

    <!-- 查看详情的弹窗 -->
    <a-modal v-model:open="viewModalVisible" title="详细信息" :footer="null">
      <a-descriptions :column="1" bordered>
        <a-descriptions-item label="ID">{{ selectedRecord[idField.value] }}</a-descriptions-item>
        <a-descriptions-item label="用户ID">{{ selectedRecord.userId }}</a-descriptions-item>
        <a-descriptions-item label="用户名">{{ selectedRecord.username }}</a-descriptions-item>
        <a-descriptions-item label="标题">{{ selectedRecord.title }}</a-descriptions-item>
        <a-descriptions-item label="内容">{{ selectedRecord.content }}</a-descriptions-item>
        <a-descriptions-item label="头像">
          <a-image :src="selectedRecord.avatarUrl" :width="50" :height="50" style="border-radius: 6px" />
        </a-descriptions-item>
        <a-descriptions-item label="图片">
          <div v-if="selectedRecord.imageUrls">
            <a-image
                v-for="(url, index) in parseImageUrls(selectedRecord.imageUrls)"
                :key="index"
                :src="url"
                :width="50"
                :height="50"
                style="border-radius: 6px; margin-right: 5px"
            />
          </div>
          <span v-else>无图片</span>
        </a-descriptions-item>
        <a-descriptions-item label="创建时间">{{ selectedRecord.createTime }}</a-descriptions-item>

        <!-- 条件展示 startDate 和 endDate -->
        <a-descriptions-item v-if="selectedRecord.startDate" label="开始时间">{{ selectedRecord.startDate }}</a-descriptions-item>
        <a-descriptions-item v-if="selectedRecord.endDate" label="结束时间">{{ selectedRecord.endDate }}</a-descriptions-item>
      </a-descriptions>
    </a-modal>
  </a-card>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import axios from 'axios';

// 当前激活的标签页 key
const activeKey = ref('dynamic');

// 数据列表
const dataList = ref([]);

// 主键字段（动态）
const idField = computed(() => `${activeKey.value}Id`);

// 表格列配置
const columns = computed(() => {
  // 公共列
  const baseColumns = [
    { title: 'ID', dataIndex: idField.value, key: 'id' },
    { title: '用户ID', dataIndex: 'userId', key: 'userId' },
    { title: '用户名', dataIndex: 'username', key: 'username' },
    { title: '头像', dataIndex: 'avatarUrl', key: 'avatarUrl' },
    { title: '标题', dataIndex: 'title', key: 'title' },
    { title: '内容', dataIndex: 'content', key: 'content' },
    { title: '创建时间', dataIndex: 'createTime', key: 'createTime' },
    { title: '操作', dataIndex: 'action', key: 'action' },
  ];

  // 针对 'event' 和 'homework' 标签页，添加 startDate 和 endDate
  if (['event', 'homework'].includes(activeKey.value)) {
    baseColumns.splice(5, 0,
        { title: '开始时间', dataIndex: 'startDate', key: 'startDate' },
        { title: '结束时间', dataIndex: 'endDate', key: 'endDate' }
    );
  }

  return baseColumns;
});

// 解析 JSON 图片 URL 列表
const parseImageUrls = (imageUrls) => {
  try {
    return JSON.parse(imageUrls || '[]');
  } catch {
    return [];
  }
};

// 获取数据
const fetchData = () => {
  axios
      .get(`http://localhost/backend/get_all_affairData.php?type=${activeKey.value}`)
      .then((response) => {
        dataList.value = response.data;
      })
      .catch((error) => {
        console.error('获取数据失败:', error);
      });
};

// 删除记录
const deleteRecord = (record) => {
  axios
      .post('http://localhost/backend/delete_affairData.php', {
        table: `user_${activeKey.value}`,
        id: record[idField.value],
      })
      .then((response) => {
        if (response.data.status === 'success') {
          fetchData();
        } else {
          alert(response.data.message);
        }
      })
      .catch((error) => {
        console.error('删除记录失败:', error);
      });
};

// 查看记录
const viewRecord = (record) => {
  selectedRecord.value = record;
  viewModalVisible.value = true;
};

// 查看详情相关数据
const viewModalVisible = ref(false);
const selectedRecord = ref({});

onMounted(fetchData);
</script>


<style scoped>
a-card {
  margin-top: 20px;
}
</style>
