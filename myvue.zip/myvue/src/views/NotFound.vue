<script setup>

</script>

<template>
<div>404,找不到网页</div>
</template>

<style scoped>

</style>