<script setup>

</script>

<template>
  <div >

  </div>
  <router-view />
</template>

<style scoped>

</style>