<script setup>
import { ref, watch } from 'vue';
import { useRouter } from 'vue-router';

// 存储留言数据
const name = ref('');
const message = ref('');
const messages = ref([]);


// 初始化时从 localStorage 加载留言数据
const loadMessages = () => {
  const savedMessages = JSON.parse(localStorage.getItem('messages')) || [];
  messages.value = savedMessages;
};

// 监听 messages 数组的变化并保存到 localStorage
watch(messages, (newMessages) => {
  localStorage.setItem('messages', JSON.stringify(newMessages));
}, { deep: true });

// 添加留言
const addMessage = () => {
  if (!name.value.trim() || !message.value.trim()) {
    return;
  }

  const newMessage = { name: name.value, message: message.value };

  // 将新留言添加到 messages 数组
  messages.value.push(newMessage);

  // 清空输入框
  name.value = '';
  message.value = '';

  // 跳转到留言展示页面

};

// 加载留言数据
loadMessages();
</script>

<template>
  <!-- 留言输入表单 -->
  <a-form layout="inline" @submit.prevent="addMessage" style="margin-bottom: 20px">
    <a-form-item>
      <a-input v-model="name" placeholder="你的名字" style="width: 150px" />
    </a-form-item>
    <a-form-item>
      <a-input v-model="message" placeholder="你的留言" style="width: 300px" />
    </a-form-item>
    <a-form-item>
      <a-button type="primary" html-type="submit" @click="addMessage">添加留言</a-button>
    </a-form-item>
  </a-form>
</template>
