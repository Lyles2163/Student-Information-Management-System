<script setup>
import { ref, onMounted } from 'vue';

// 存储留言列表
const messages = ref([]);

// 加载留言数据
onMounted(() => {
  // 从 localStorage 加载留言数据
  const savedMessages = JSON.parse(localStorage.getItem('messages')) || [];
  messages.value = localStorage.getItem('messages');

});
</script>

<template>
  <a-list bordered :data-source="messages">
    <a-list-item v-for="(item, index) in messages" :key="index">
      <a-typography-text strong>{{ item.name }}</a-typography-text>：
      <a-typography-text>{{ item.message }}</a-typography-text>
    </a-list-item>
  </a-list>
</template>