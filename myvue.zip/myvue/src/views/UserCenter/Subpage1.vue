<template>
  <div class="edit-profile">
    <h2>编辑个人信息</h2>
    <a-form @submit.prevent="onSubmit" layout="vertical">
      <a-form-item label="个人签名" :validate-status="form.slogan ? 'success' : 'error'" help="请输入个人签名">
        <a-input v-model:value="form.slogan" placeholder="请输入个人签名" />
      </a-form-item>

      <a-form-item label="职位" :validate-status="form.jobTitle ? 'success' : 'error'" help="请输入职位">
        <a-input v-model:value="form.jobTitle" placeholder="请输入职位" />
      </a-form-item>

      <a-form-item label="公司" :validate-status="form.company ? 'success' : 'error'" help="请输入公司名称">
        <a-input v-model:value="form.company" placeholder="请输入公司名称" />
      </a-form-item>

      <a-form-item label="所在地" :validate-status="form.location ? 'success' : 'error'" help="请输入所在地">
        <a-input v-model:value="form.location" placeholder="请输入所在地" />
      </a-form-item>

      <a-form-item label="梦想与目标" :validate-status="form.dreamGoal ? 'success' : 'error'" help="请输入梦想与目标">
        <a-textarea v-model:value="form.dreamGoal" placeholder="请输入梦想与目标" />
      </a-form-item>

      <a-form-item>
        <a-button type="primary" html-type="submit">提交修改</a-button>
      </a-form-item>
    </a-form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useUserStore } from "../../stores/userStore.js"
import { message } from 'ant-design-vue'

const userStore = useUserStore()

// 用户信息表单
const form = ref({
  slogan: '',
  jobTitle: '',
  company: '',
  location: '',
  dreamGoal: ''
})

// 提交表单
const onSubmit = async () => {
  if (Object.values(form.value).some(field => !field)) {
    message.error("请填写所有字段")
    return
  }

  const updatedInfo = {
    userID: localStorage.getItem("userID"),
    ...form.value
  }

  try {
    await userStore.updateUserInfo(updatedInfo)
    message.success("个人信息更新成功")
  } catch (error) {
    message.error("更新失败，请稍后再试")
  }
}
</script>

<style scoped>
.edit-profile {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
}

h2 {
  text-align: center;
  margin-bottom: 20px;
}

.a-form-item {
  margin-bottom: 20px;
}
</style>
