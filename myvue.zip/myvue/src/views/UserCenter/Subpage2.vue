<template>
  <div class="profile-page">
    <!-- 左侧内容 -->
    <div class="profile-left">
      <!-- 左侧上半部分: 个人信息展示和梦想与目标 -->
      <div class="profile-upper">
        <!-- 个人信息区域 -->
        <div class="profile-info">
          <a-skeleton :loading="loading" :active="true" avatar :paragraph="{ rows: 6, width: ['100%', '70%', '80%', '90%'] }">
            <div>
              <a-avatar :size="80" :src="avatarUrl" />
              <h2 class="profile-username">{{ currentUsername }}</h2>
              <div v-if="jobTitle===''"><strong>口号：</strong>该用户还没填写自己的口号哟~</div>
              <div v-else><strong>口号：</strong>{{slogan}}</div>
              <div class="profile-details">
                <div v-if="jobTitle===''"><strong>职位：</strong>该用户还没填写自己的职位哟~</div>
                <div v-else><strong>职位：</strong>{{jobTitle}}</div>
                <div v-if="company===''"><strong>公司：</strong>该用户还没填写自己的公司哟~</div>
                <div v-else><strong>公司：</strong>{{company}}</div>
                <div v-if="location===''"><strong>所在地：</strong>该用户还没填写自己的所在地哟~</div>
                <div v-else><strong>所在地：</strong>{{location}}</div>
              </div>
              <div class="profile-tags">
                <a-tag color="blue">很有想法的</a-tag>
                <a-tag color="blue">专注设计</a-tag>
                <a-tag color="blue">辣~~</a-tag>
                <a-tag color="blue">大长腿</a-tag>
                <a-tag color="blue">川妹子</a-tag>
                <a-tag color="blue">海纳百川</a-tag>
              </div>
            </div>
          </a-skeleton>
        </div>

        <!-- 个人梦想与目标区域 -->
        <div class="profile-dreams">
          <a-skeleton :loading="loading" :active="true" :paragraph="{ rows: 6, width: ['100%', '70%', '80%', '90%'] }">
            <a-card title="个人梦想与目标" class="profile-card">
               <div v-if="dreamGoal===''">该用户还没写自己的梦想与目标哟~</div>
              <div v-else>{{dreamGoal}}</div>
            </a-card>
          </a-skeleton>
        </div>
      </div>

      <!-- 左侧下半部分: 文章、应用、项目 -->
      <div class="profile-content">
        <a-skeleton :loading="loading" :active="true" :paragraph="{rows:12}">
          <a-tabs type="card">
            <a-tab-pane tab="文章(3)" key="articles">
              <a-list :dataSource="articleData" bordered>
                <template #renderItem="{ item }">
                  <a-list-item>
                    <a-list-item-meta :title="item.title" :description="item.description" />
                    <template #extra>
                      <a>{{ item.extra }}</a>
                    </template>
                  </a-list-item>
                </template>
              </a-list>
            </a-tab-pane>
            <a-tab-pane tab="应用(3)" key="apps">
              <a-list :dataSource="appData" bordered>
                <template #renderItem="{ item }">
                  <a-list-item>
                    <a-list-item-meta :title="item.title" :description="item.description" />
                    <template #extra>
                      <a>{{ item.extra }}</a>
                    </template>
                  </a-list-item>
                </template>
              </a-list>
            </a-tab-pane>
            <a-tab-pane tab="项目(3)" key="projects">
              <a-list :dataSource="projectData" bordered>
                <template #renderItem="{ item }">
                  <a-list-item>
                    <a-list-item-meta :title="item.title" :description="item.description" />
                    <template #extra>
                      <a>{{ item.extra }}</a>
                    </template>
                  </a-list-item>
                </template>
              </a-list>
            </a-tab-pane>
          </a-tabs>
        </a-skeleton>
      </div>
    </div>

    <!-- 右侧新增内容 -->
    <div class="profile-right">
      <!-- 统计信息面板 -->
      <a-card title="统计信息" class="profile-card">
        <a-skeleton :loading="loading" :active="true" paragraph>
          <a-statistic title="访问量" :value=stats.views />
          <a-statistic title="点赞数" :value=stats.likes style="margin-top: 16px;" />
          <a-statistic title="收藏数" :value=stats.favorites style="margin-top: 16px;" />
        </a-skeleton>
      </a-card>

      <!-- 最近动态 -->
      <a-card title="最近动态" class="profile-card">
        <a-skeleton :loading="loading" :active="true" paragraph>
          <a-list>
            <a-list-item>新增文章《前端开发的未来》</a-list-item>
            <a-list-item>点赞了《Vue3实战教程》</a-list-item>
            <a-list-item>加入了“设计师联盟”小组</a-list-item>
          </a-list>
        </a-skeleton>
      </a-card>

      <!-- 推荐内容 -->
      <a-card title="推荐内容" class="profile-card">
        <a-skeleton :loading="loading" :active="true" paragraph>
          <a-list>
            <a-list-item>文章《如何快速掌握JavaScript》</a-list-item>
            <a-list-item>项目《Vue电商平台开发》</a-list-item>
            <a-list-item>用户“张小白”</a-list-item>
          </a-list>
        </a-skeleton>
      </a-card>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import Mock from "mockjs";
import { message } from "ant-design-vue";
import request from "../../axio/request.js";
const avatarUrl = localStorage.getItem("avatarUrl");
const currentUsername = localStorage.getItem("currentUsername");
const stats = ref({
  views: 0,
  likes: 0,
  favorites: 0,
});
const loading = ref(true);
const articleData = ref([]);
const appData = ref([]);
const projectData = ref([]);
const slogan = ref("");
const jobTitle = ref("");
const company = ref("");
const location= ref("");
const dreamGoal = ref("");

// 调用接口加载用户数据
const fetchUserInformation = async () => {
  const userID = localStorage.getItem("userID");

  if (!userID) {
    message.error("未找到用户 ID，请重新登录！");
    router.push("/login");
    return;
  }

  try {
    const res = await request({
      url: `http://localhost/backend/get_user_info.php?userId=${userID}`,
      method: "get",
    });

    if (res.data.code === 200) {
      const userInfo = res.data.data;
      slogan.value = userInfo.slogan;
      jobTitle.value = userInfo.jobTitle;
      company.value = userInfo.company;
      location.value = userInfo.location;
      dreamGoal.value = userInfo.dreamGoal;
      console.log("用户个人信息:", userInfo);
      // 更新状态或显示用户信息
    } else {
      message.error(res.data.message || "获取用户信息失败！");
    }
  } catch (error) {
    console.error("请求失败", error);
    message.error("服务器错误，请稍后再试！");
  }
};


onMounted(() => {
  fetchUserInformation();
  setTimeout(() => {
    const mockData = Mock.mock({
      views: "@integer(100000, 999999)", // 模拟访问量
      likes: "@integer(1000, 9999)",    // 模拟点赞数
      favorites: "@integer(100, 999)", // 模拟收藏数
    });

    stats.value = mockData;
    loading.value = false;
    // articleData.value =
    // [
    //   { title: "文章标题1", description: "描述信息1", extra: "附加信息1" },
    //   { title: "文章标题2", description: "描述信息2", extra: "附加信息2" },
    //   { title: "文章标题3", description: "描述信息3", extra: "附加信息3" }
    // ];
    // appData.value =
    // [
    //   { title: "应用标题1", description: "描述信息1", extra: "附加信息1" },
    //   { title: "应用标题2", description: "描述信息2", extra: "附加信息2" },
    //   { title: "应用标题3", description: "描述信息3", extra: "附加信息3" }
    // ];
    // projectData.value = [
    //   { title: "项目标题1", description: "描述信息1", extra: "附加信息1" },
    //   { title: "项目标题2", description: "描述信息2", extra: "附加信息2" },
    //   { title: "项目标题3", description: "描述信息3", extra: "附加信息3" }
    // ];
  }, 1500);
});
</script>

<style scoped>
.profile-page {
  display: flex;
  gap: 20px;
  padding: 20px;
  background-color: #f5f5f5;
}

.profile-left {
  flex: 2;
}

.profile-right {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* 上半部分：个人信息展示 + 梦想与目标 */
.profile-upper {
  display: flex;
  gap: 20px;
}

.profile-info,
.profile-dreams {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  width: 50%;
}

.profile-info {
  flex: 1;
}

.profile-dreams {
  flex: 1;
}

.profile-username {
  font-size: 20px;
  font-weight: bold;
  margin: 10px 0;
}

.profile-slogan {
  color: #888;
  margin-bottom: 20px;
}

.profile-details {
  margin-bottom: 20px;
  font-size: 14px;
  color: #666;
}

.profile-tags a-tag {
  margin: 5px;
}

.profile-content {
  background-color: #fff;
  margin-top: 25px;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.profile-right .profile-card {
  background-color: #fff;
  padding: 8px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
</style>