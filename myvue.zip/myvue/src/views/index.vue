<script setup>
import Mock from 'mockjs';
import * as echarts from 'echarts';
import { inject, onMounted, ref, watch } from 'vue';
import {useVueDataStore} from "../stores/vueDataStore.js";
const homeworkRate = ref((Math.random() * 50 + 50).toFixed(2));
const activityRate = ref(Math.floor(Math.random() * 41) + 10);
const knowledgePoints = ref(Math.floor(Math.random() * 31) + 10);

const today = ref(new Date().getDate());
const daysInMonth = ref(new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate());
const vueDataStore = useVueDataStore();
  vueDataStore.getVueData();

const vueData= vueDataStore.vueData;
const mysqlData=vueDataStore.mysqlData;
const phpData=vueDataStore.phpData;
const javaData=vueDataStore.javaData;
const learnTime=vueDataStore.learnTime;

const years = ['7月', '8月', '9月', '10月', '11月', '12月'];
const products = ['娱乐时长', '学习时长', '运动时长', '志愿时长'];
const source = [
  ['product', ...years],  // 第一行是产品名称和年份
  ...products.map(product => [
    product,
    ...Mock.mock({ "array|6": ["@float(20, 100, 1, 1)"] }).array  // 模拟 6 个浮动的数值
  ])
];

onMounted(async () => {
  await vueDataStore.getVueData();
  initChart('light'); // 初始化图表
});

// 动态更新图表数据
watch(
    () => vueDataStore.vueData,
    (newData) => {
      if (myChart) {
        myChart.setOption({
          series: [
            {
              data: newData, // 更新图表数据
            },
          ],
        });
        // console.log('图表数据已更新:', newData);
      }
    }
);

const currentUserID = ref(vueDataStore.id);
watch(currentUserID, (newValue, oldValue) => {
  myChart.setOption({
    series: [
      {
        vueData: vueDataStore.vueData,
        mysqlData: vueDataStore.mysqlData,
        phpData:vueDataStore.phpData,
        javaData:vueDataStore.javaData,
      },
    ],
  });
  myChart2.setOption({
    series: [
      {
        learnTime: vueDataStore.learnTime,
      },
    ],
  });
});



const chartDom = ref(null);
const chartDom2 = ref(null);
const chartDom3 = ref(null);
let myChart;
let myChart2;
let myChart3;

const theme = inject('theme');

const initChart = (themeValue) => {
  if (myChart) myChart.dispose();
  if (myChart2) myChart2.dispose();
  if (myChart3) myChart3.dispose();

  // 初始化第一个图表
  myChart = echarts.init(chartDom.value, themeValue);
  const option1 = {
    color: ['#80FFA5', '#00DDFF', '#37A2FF', '#FF0087', '#FFBF00'],
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross', label: { backgroundColor: '#6a7985' } },
    },
    legend: { data: ['vue',  'mysql', 'php', 'javascript'] },
    toolbox: { feature: { saveAsImage: {} } },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: [{ type: 'category', boundaryGap: false, data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'] }],
    yAxis: [{ type: 'value' }],
    series: [
      { name: 'vue', type: 'line', stack: 'Total', smooth: true, lineStyle: { width: 0 }, showSymbol: false, areaStyle: { opacity: 0.8, color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgb(128, 255, 165)' }, { offset: 1, color: 'rgb(1, 191, 236)' }]) }, emphasis: { focus: 'series' }, data: vueData },
      { name: 'mysql', type: 'line', stack: 'Total', smooth: true, lineStyle: { width: 0 }, showSymbol: false, areaStyle: { opacity: 0.8, color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgb(0, 221, 255)' }, { offset: 1, color: 'rgb(77, 119, 255)' }]) }, emphasis: { focus: 'series' }, data: mysqlData },
      { name: 'php', type: 'line', stack: 'Total', smooth: true, lineStyle: { width: 0 }, showSymbol: false, areaStyle: { opacity: 0.8, color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgb(255, 0, 135)' }, { offset: 1, color: 'rgb(135, 0, 157)' }]) }, emphasis: { focus: 'series' }, data: phpData },
      { name: 'javascript', type: 'line', stack: 'Total', smooth: true, lineStyle: { width: 0 }, showSymbol: false, label: { show: true, position: 'top' }, areaStyle: { opacity: 0.8, color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgb(255, 191, 0)' }, { offset: 1, color: 'rgb(224, 62, 76)' }]) }, emphasis: { focus: 'series' }, data:javaData},
    ],
  };
  myChart.setOption(option1);

  // 初始化第二个图表
  myChart2 = echarts.init(chartDom2.value, themeValue);
  const option2 = {
    title: { text: '每日学习时长', subtext: '你的所有努力都不会白费' },
    xAxis: {
      data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
      axisLabel: { inside: true, color: '#fff' },
      axisTick: { show: false },
      axisLine: { show: false },
      z: 10,
    },
    yAxis: { axisLine: { show: false }, axisTick: { show: false }, axisLabel: { color: '#999' } },
    dataZoom: [{ type: 'inside' }],
    series: [
      {
        type: 'bar',
        showBackground: true,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: '#00ffbb' },
            { offset: 0.5, color: '#188df0' },
            { offset: 1, color: '#188df0' },
          ])
        },
        emphasis: {
          itemStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              { offset: 0, color: '#2378f7' },
              { offset: 0.7, color: '#2378f7' },
              { offset: 1, color: '#83bff6' },
            ])
          }
        },
        data:learnTime,
      }
    ]
  };
  myChart2.setOption(option2);

  // 初始化第三个图表并动态联动
  myChart3 = echarts.init(chartDom3.value, themeValue);
  const option3 = {
    legend: {},
    tooltip: {
      trigger: 'axis',
      showContent: false
    },
    dataset: {
      source: source,
    },
    xAxis: { type: 'category' },
    yAxis: { gridIndex: 0 },
    grid: { top: '55%' },
    series: [
      { type: 'line', smooth: true, seriesLayoutBy: 'row', emphasis: { focus: 'series' } },
      { type: 'line', smooth: true, seriesLayoutBy: 'row', emphasis: { focus: 'series' } },
      { type: 'line', smooth: true, seriesLayoutBy: 'row', emphasis: { focus: 'series' } },
      { type: 'line', smooth: true, seriesLayoutBy: 'row', emphasis: { focus: 'series' } },
      {
        type: 'pie',
        id: 'pie',
        radius: '30%',
        center: ['50%', '25%'],
        emphasis: { focus: 'self' },
        label: { formatter: '{b}: {@12月} ({d}%)' },
        encode: {
          itemName: 'product',
          value: '12月',
          tooltip: '12月'
        }
      }
    ]
  };


  // 动态联动
  myChart3.setOption(option3);
  myChart3.on('updateAxisPointer', function (event) {
    const xAxisInfo = event.axesInfo[0];
    if (xAxisInfo) {
      const dimension = xAxisInfo.value + 1;
      myChart3.setOption({
        series: {
          id: 'pie',
          label: {
            formatter: '{b}: {@[' + dimension + ']} ({d}%)',
          },
          encode: {
            value: dimension,
            tooltip: dimension,
          },
        },
      });
    }
  });
};

// 监听组件挂载
onMounted(() => {
  initChart(theme.value === 'dark' ? 'dark' : '');
});

// 监听主题变化
watch(theme, (newTheme) => {
  initChart(newTheme === 'dark' ? 'dark' : '');
});

// 动态背景颜色
const getDivBgColor = () => {
  return theme.value === 'dark' ? 'rgb(16,12,42)' : '#fff';
};
</script>

<template>
  <div class="divbox">
    <div class="divbox_large1">
      <div class="divbox_large1_middle" style="display: flex; flex-direction: column">
        <div style="display:flex;flex-direction: row;justify-content: space-around">
          <h2 style="padding-top: 20px;font-size: 2.8vh;;color: white;transform: translateY(5px);text-shadow: black 0 2px 5px">作业提交</h2>
          <svg
              xmlns="http://www.w3.org/2000/svg" width="4em" height="4em" viewBox="0 0 24 24"><g fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path stroke-dasharray="72" stroke-dashoffset="72" d="M12 3h7v18h-14v-18h7Z"><animate fill="freeze" attributeName="stroke-dashoffset" dur="0.6s" values="72;0"/></path><path stroke-dasharray="12" stroke-dashoffset="12" stroke-width="1" d="M14.5 3.5v3h-5v-3"><animate fill="freeze" attributeName="stroke-dashoffset" begin="0.7s" dur="0.2s" values="12;0"/></path><path stroke-dasharray="4" stroke-dashoffset="4" d="M9 10h3"><animate fill="freeze" attributeName="stroke-dashoffset" begin="0.9s" dur="0.2s" values="4;0"/></path><path stroke-dasharray="6" stroke-dashoffset="6" d="M9 13h5"><animate fill="freeze" attributeName="stroke-dashoffset" begin="1.1s" dur="0.2s" values="6;0"/></path><path stroke-dasharray="8" stroke-dashoffset="8" d="M9 16h6"><animate fill="freeze" attributeName="stroke-dashoffset" begin="1.3s" dur="0.2s" values="8;0"/></path></g></svg>

        </div>
        <p style="padding-top: 50px;padding-right:80px;text-shadow: black 0 1px 5px ;color: white; text-align: center; font-size: 16px;">本学期作业完成率：<span style="font-size: 40px;">{{ homeworkRate }}</span> %</p>
      </div>
      <div class="divbox_large1_middle" style="display: flex; flex-direction: column">
        <div style="display:flex;flex-direction: row;justify-content: space-around">
          <h2 style="padding-top: 20px;font-size: 2.8vh;;color: white;transform: translateY(5px);text-shadow: black 0 2px 5px">校园活动</h2>
        <svg
            xmlns="http://www.w3.org/2000/svg" width="4em" height="4em" viewBox="0 0 24 24"><path fill="#ffffff" d="M12 15c-2.5 0 -3.25 0 -4 0c-0.55 0 -1 0 -1 0c0 0 1.5 0 5 0c3.5 0 5 0 5 0c0 0 -0.45 0 -1 0c-0.75 0 -1.5 0 -4 0Z"><animate fill="freeze" attributeName="d" begin="1.1s" dur="0.2s" values="M12 15c-2.5 0 -3.25 0 -4 0c-0.55 0 -1 0 -1 0c0 0 1.5 0 5 0c3.5 0 5 0 5 0c0 0 -0.45 0 -1 0c-0.75 0 -1.5 0 -4 0Z;M12 14c-2.5 0 -3.25 -1 -4 -1c-0.55 0 -1 0.45 -1 1c0 0.75 1.5 4 5 4c3.5 0 5 -3.25 5 -4c0 -0.55 -0.45 -1 -1 -1c-0.75 0 -1.5 1 -4 1Z"/></path><g fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path stroke-dasharray="64" stroke-dashoffset="64" d="M12 3c4.97 0 9 4.03 9 9c0 4.97 -4.03 9 -9 9c-4.97 0 -9 -4.03 -9 -9c0 -4.97 4.03 -9 9 -9"><animate fill="freeze" attributeName="stroke-dashoffset" dur="0.6s" values="64;0"/></path><path stroke-dasharray="2" stroke-dashoffset="2" d="M9 9v1"><animate fill="freeze" attributeName="stroke-dashoffset" begin="0.7s" dur="0.2s" values="2;0"/></path><path stroke-dasharray="2" stroke-dashoffset="2" d="M15 9v1"><animate fill="freeze" attributeName="stroke-dashoffset" begin="0.9s" dur="0.2s" values="2;0"/></path></g></svg>

        </div>
        <p style="padding-top: 50px;padding-right:80px;text-shadow: black 0 1px 5px ;color: white; text-align: center; font-size: 16px;">本学期活动参与度：<span style="font-size: 40px;">{{ activityRate }}</span> 个</p>
        </div>
      <div class="divbox_large1_middle" style="display: flex; flex-direction: column">
        <div style="display:flex;flex-direction: row;justify-content: space-around">
          <h2 style="padding-top: 20px;font-size: 2.8vh;;color: white;transform: translateY(5px);text-shadow: black 0 2px 5px">课外拓展</h2>
        <svg
            xmlns="http://www.w3.org/2000/svg" width="4em" height="4em" viewBox="0 0 24 24"><g fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path stroke-dasharray="6" stroke-dashoffset="6" d="M12 21h5M12 21h-5"><animate fill="freeze" attributeName="stroke-dashoffset" dur="0.3s" values="6;0"/></path><path stroke-dasharray="6" stroke-dashoffset="6" d="M12 21v-4"><animate fill="freeze" attributeName="stroke-dashoffset" dur="0.3s" values="6;0"/></path><path stroke-dasharray="64" stroke-dashoffset="64" d="M12 17h-9v-12h18v12Z"><animate fill="freeze" attributeName="stroke-dashoffset" begin="0.3s" dur="0.6s" values="64;0"/></path></g></svg>

        </div>
        <p style="padding-top: 50px;padding-right:80px;text-shadow: black 0 1px 5px ;color: white; text-align: center; font-size: 16px;">本学期课外拓展知识点：<span style="font-size: 40px;">{{ knowledgePoints }}</span> 个</p>
      </div>
      <div class="divbox_large1_middle" style="display: flex; flex-direction: column">
        <div style="display:flex;flex-direction: row;justify-content: space-around">
          <h2 style="padding-top: 20px;font-size: 2.8vh;;color: white;transform: translateY(5px);text-shadow: black 0 2px 5px">本月日历</h2>
        <svg
            xmlns="http://www.w3.org/2000/svg" width="4em" height="4em" viewBox="0 0 24 24"><rect width="14" height="0" x="5" y="5" fill="#ffffff"><animate fill="freeze" attributeName="height" begin="0.6s" dur="0.2s" values="0;3"/></rect><g fill="none" stroke="#ffffff" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path stroke-dasharray="64" stroke-dashoffset="64" d="M12 4h7c0.55 0 1 0.45 1 1v14c0 0.55 -0.45 1 -1 1h-14c-0.55 0 -1 -0.45 -1 -1v-14c0 -0.55 0.45 -1 1 -1Z"><animate fill="freeze" attributeName="stroke-dashoffset" dur="0.6s" values="64;0"/></path><path stroke-dasharray="4" stroke-dashoffset="4" d="M7 4v-2M17 4v-2"><animate fill="freeze" attributeName="stroke-dashoffset" begin="0.6s" dur="0.2s" values="4;0"/></path><path stroke-dasharray="12" stroke-dashoffset="12" d="M7 11h10"><animate fill="freeze" attributeName="stroke-dashoffset" begin="0.8s" dur="0.2s" values="12;0"/></path><path stroke-dasharray="8" stroke-dashoffset="8" d="M7 15h7"><animate fill="freeze" attributeName="stroke-dashoffset" begin="1s" dur="0.2s" values="8;0"/></path></g></svg>

       </div>
        <div style="padding-top: 50px;padding-right:80px;text-shadow: black 0 1px 5px ;color: white; text-align: center; font-size: 16px;">
          <p>本月已过：<span style="font-size: 40px;">{{ today }} / {{ daysInMonth }}</span> 天</p>
        </div>
        </div>
    </div>

    <div class="divbox_large2">
      <div class="divbox_large2_middle1">
        <div class="divbox_large2_middle1_small" ref="chartDom" :style="{ background: getDivBgColor() }"></div>
        <div class="divbox_large2_middle1_small" ref="chartDom2" :style="{ background: getDivBgColor() }"></div>
      </div>
      <div class="divbox_large2_middle2" ref="chartDom3" :style="{ background: getDivBgColor() }"></div>
    </div>
  </div>
</template>

<style scoped>
.divbox_large1_middle:first-child{
  background: linear-gradient(45deg,rgb(0, 221, 255), rgb(48, 95, 248));
}

.divbox_large1_middle:nth-child(2){
  background: linear-gradient(60deg,rgb(255, 255, 0), rgb(255, 89, 0));
}
.divbox_large1_middle:nth-child(3){
  background: linear-gradient(225deg, rgb(36, 178, 255), rgb(79, 255, 131));
}
.divbox_large1_middle:last-child{
  background: linear-gradient(225deg, rgb(85, 0, 255), rgb(230, 0, 255));
}
.divbox_large1_middle,.divbox_large2_middle1_small,.divbox_large2_middle2{
  box-shadow: #9c9b9b 0px 0px 0.1vh;
  border-radius: 0.5vh;
}
.divbox_large1_middle:hover{
  box-shadow: #9c9b9b 0px 0px 0.6vh;
  transition: all 0.5s;
  transform: scale(1.05);
}
.divbox_large2_middle1_small:hover,.divbox_large2_middle2:hover{
  box-shadow: #9c9b9b 0px 0px 0.6vh;
  transition: all 0.5s;
  transform: scale(1.002);
}
.divbox {
  display: flex;
  flex-direction: column;
  height: 100%;
}
.divbox_large1 {
  display: flex;
  flex: 2;
}
.divbox_large1_middle {
  flex: 1;
  margin: 3vh 2vh;
  background-color: #f5f5f5;
}
.divbox_large2 {
  display: flex;
  flex: 5;
}
.divbox_large2_middle1 {
  display: flex;
  flex: 1;
  flex-direction: column;
}
.divbox_large2_middle1_small {
  flex: 1;
  margin: 5px;
}
.divbox_large2_middle2 {
  flex: 2;
  margin: 5px;
}
</style>
