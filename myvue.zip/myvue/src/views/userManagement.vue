<script setup>
import {inject, onMounted, reactive, ref} from "vue";
import {
  message,
  Popconfirm,

  ConfigProvider,
} from "ant-design-vue";
import dayjs from "dayjs";
import zhCN from "ant-design-vue/es/locale/zh_CN";
import request from "../axio/request.js";
import axios from "axios";
import {useUserStore} from "../stores/userStore";

const userStore = useUserStore();
// 获取全局主题
const theme = inject("theme");
const searchValue = ref(""); // 搜索框的值

// 表格数据相关
const data = ref([]);
const currentPage = ref(1); // 当前页码
const pageSize = ref(9); // 每页显示条数
const total = ref(0); // 总条数

const isModalVisible = ref(false); // 控制弹窗显示
const isEditMode = ref(false); // 是否是编辑模式
const userForm = reactive({
  id: null,
  username: "",
  avatarUrl: "",
  userAccount: "",
  userPassword: "",
  gender: "男",
  age: null,
  userRole: 0,
});

// 获取表格数据
// const getUserData = () => {
//   request({
//     url: "/Mock/usersData",
//     method: "get",
//   })
//       .then((res) => {
//         if (res.data.code === 200 && Array.isArray(res.data.usersData)) {
//           data.value = res.data.usersData;
//           total.value = res.data.usersData.length;
//           // localStorage.setItem("usersDataAll", JSON.stringify(res.data.usersData));
//         } else {
//           message.error("数据格式错误或无数据");
//         }
//       })
//       .catch((error) => {
//         message.error("请求失败");
//         console.error("错误详情:", error);
//       });
// };
onMounted(async () => {
  await userStore.fetchUserData(); // 从 Pinia 获取用户数据
  data.value = userStore.userData; // 将数据赋值给本地变量，或直接在模板中使用 userStore.userData
});

// 打开添加用户弹窗
const showAddUserModal = () => {
  isEditMode.value = false;
  isModalVisible.value = true;
  resetForm();
};

// 打开编辑用户弹窗
const editUser = (id) => {
  const user = data.value.find((item) => item.id === id);
  if (user) {
    isEditMode.value = true;
    isModalVisible.value = true;
    Object.assign(userForm, user); // 填充表单
  }
};

// 重置表单
const resetForm = () => {
  Object.keys(userForm).forEach((key) => {
    userForm[key] = key === "gender" ? "男" : key === "userRole" ? 0 : "";
  });
};

// 提交用户表单
const handleFormSubmit = async () => {
  // 校验表单字段
  if (
      !userForm.username ||
      !userForm.avatarUrl ||
      !userForm.userAccount ||
      !userForm.userPassword ||
      userForm.age === null
  ) {
    message.error("请填写完整信息");
    return;
  }

  try {
    let response;
    if (isEditMode.value) {
      // 编辑模式，发送 PUT 请求
      response = await axios.put(`http://localhost/backend/edit_user.php?id=${userForm.id}`, userForm);
    } else {
      // 添加模式，发送 POST 请求
      response = await axios.post("http://localhost/backend/add_user.php", userForm);
    }

    if (response.data.code === 200) {
      // 操作成功后，更新数据或显示成功消息
      if (isEditMode.value) {
        const index = data.value.findIndex((user) => user.id === userForm.id);
        if (index !== -1) {
          data.value[index] = {...userForm}; // 更新表格中的数据
        }
        message.success("用户信息已更新");
      } else {
        data.value.push({...userForm, id: data.value.length + 1, createTime: new Date()}); // 新增用户到表格
        total.value++;
        message.success("用户添加成功");
      }
      isModalVisible.value = false; // 关闭弹窗
      resetForm(); // 重置表单
    } else {
      message.error(response.data.msg || "操作失败");
    }
  } catch (error) {
    message.error("请求失败，请稍后再试");
    console.error("错误详情:", error);
  }
};


// 删除用户
const deleteUser = (id) => {
  request({
    url: `http://localhost/backend/deleteUser.php?id=${id}`,
    method: "delete",
  })
      .then((res) => {
        if (res.data.code === 200) {
          data.value = data.value.filter((user) => user.id !== id);
          total.value--;
          message.success("用户删除成功");
        } else {
          message.error("删除失败");
        }
      })
      .catch((error) => {
        message.error("请求失败");
        console.error("删除失败:", error);
      });
};

// 搜索用户
const onSearch = () => {
  request({
    url: "http://localhost/backend/searchUsers.php",
    method: "get",
    params: {username: searchValue.value},
  })
      .then((res) => {
        if (res.data.code === 200) {
          data.value = res.data.usersData;
          message.success("搜索成功");
        } else {
          message.error("搜索失败");
        }
      })
      .catch((error) => {
        message.error("请求失败");
        console.error("错误详情:", error);
      });
};


// 分页功能
const handlePageChange = (pagination) => {
  currentPage.value = pagination.current;
  pageSize.value = pagination.pageSize;
};

// 根据主题动态设置样式
const getPageBgColor = () => (theme.value === "dark" ? 'rgb(16,12,42)' : '#fff');
const getTextColor = () => (theme.value === "dark" ? "#ffffff" : "#000000");
const tableHeaderColor = () => (theme.value === "dark" ? 'rgb(2,86,145)' : '#cfe3f1');
</script>

<template>
  <div :style="{ background: getPageBgColor(), color: getTextColor() }">
    <config-provider :locale="zhCN">
      <div style="display: flex; width: 88%;justify-content: right;">
        <!-- 搜索框和添加按钮 -->
        <a-input-search
            style="width: 25%; margin: 10px;"
            size="large"
            v-model:value="searchValue"
            placeholder="输入用户名搜索"
            enter-button="搜索"
            @search="onSearch"
        />
        <a-button type="primary" @click="showAddUserModal" style="margin: 10px" size="large">添加用户</a-button>

      </div>
      <div style="display: flex; justify-content: center;  ">
        <div style=" width: 98% ;box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
          <!-- 表格 -->
          <a-table :columns="[
          { title: 'ID', dataIndex: 'id', className: 'custom-header' },
          { title: '用户名', dataIndex: 'username',className: 'custom-header'  },
          { title: '头像', dataIndex: 'avatarUrl' ,className: 'custom-header' },
          { title: '账号', dataIndex: 'userAccount',className: 'custom-header'  },
          { title: '密码', dataIndex: 'userPassword',className: 'custom-header'  },
          { title: '性别', dataIndex: 'gender',className: 'custom-header'  },
          { title: '年龄', dataIndex: 'age',className: 'custom-header'  },
          { title: '用户角色', dataIndex: 'userRole',className: 'custom-header'  },
          { title: '操作', key: 'action',className: 'custom-header'  }, ]"
              :data-source="data"
              :pagination="{
          current: currentPage,
          pageSize: pageSize,
          total: total,
          showSizeChanger: true,
        }"
              @change="handlePageChange"

          >
            <template #bodyCell="{ column, record }">
              <template v-if="column.dataIndex === 'username'">
                <div>{{ record.username }}</div>
              </template>
              <template v-else-if="column.dataIndex === 'userRole'">
                <div v-if="record.userRole == 1">
                  <a-tag color="red">管理员</a-tag>
                </div>
                <div v-if="record.userRole == 2">
                  <a-tag color="orange">VIP用户</a-tag>
                </div>
                <div v-if="record.userRole == 0">
                  <a-tag color="blue">普通用户</a-tag>
                </div>
                <div v-if="record.userRole == 3">
                  <a-tag color="maroon">双创委员</a-tag>
                </div>
                <div v-if="record.userRole == 4">
                  <a-tag color="gold">伍班班长</a-tag>
                </div>
                <div v-if="record.userRole == 4">
                  <a-tag color="pink">反诈委员</a-tag>
                </div>
                <div v-if="record.userRole == 5">
                  <a-tag color="green">学习委员</a-tag>
                </div>
                <div v-if="record.userRole == 6">
                  <a-tag color="">副班长</a-tag>
                </div>
                <div v-if="record.userRole == 7">
                  <a-tag color="yellow">宣传委员</a-tag>
                </div>
                <div v-if="record.userRole == 8">
                  <a-tag color="gold">团支书</a-tag>
                </div>
                <div v-if="record.userRole == 9">
                  <a-tag color="gold">副团支书</a-tag>
                </div>
                <div v-if="record.userRole == 10">
                  <a-tag color="gold">体育委员</a-tag>
                </div>
                <div v-if="record.userRole == 11">
                  <a-tag color="gold">组织委员</a-tag>
                </div>
                <div v-if="record.userRole == 12">
                  <a-tag color="gold">劳动委员</a-tag>
                </div>
                <div v-if="record.userRole == 12">
                  <a-tag color="gold">生活委员</a-tag>
                </div>
                <div v-if="record.userRole == 13">
                  <a-tag color="gold">心理委员</a-tag>
                </div>
              </template>
              <template v-else-if="column.dataIndex === 'avatarUrl'">
                <a-image :src="record.avatarUrl" :width="50" :height="50" style="border-radius: 6px"/>
              </template>
              <template v-else-if="column.dataIndex === 'createTime'">
                {{ dayjs(record.createTime).format('YYYY-MM-DD') }}
              </template>
              <template v-else-if="column.key === 'action'">
                <!-- 确认删除弹框 -->
                <popconfirm
                    title="确认删除该用户?"
                    @confirm="() => deleteUser(record.id)"
                >
                  <a-button type="primary" danger>删除</a-button>
                </popconfirm>
                <a-button type="primary" @click="editUser(record.id)">编辑</a-button>
              </template>
              <template v-else-if="column.dataIndex === 'createTime'">
                {{ dayjs(record.createTime).format("YYYY-MM-DD") }}
              </template>
              <template v-else>
                {{ record[column.dataIndex] }}
              </template>
            </template>
          </a-table>

        </div>
      </div>

      <!-- 弹窗 -->
      <a-modal
          v-model:open="isModalVisible"
          :title="isEditMode ? '编辑用户' : '添加用户'"
          @ok="handleFormSubmit"
          @cancel="() => (isModalVisible = false)"
      >
        <a-form :model="userForm">
          <a-form-item label="用户名" required>
            <a-input v-model:value="userForm.username"/>
          </a-form-item>
          <a-form-item label="头像链接" required>
            <a-input v-model:value="userForm.avatarUrl"/>
          </a-form-item>
          <a-form-item label="账号" required>
            <a-input v-model:value="userForm.userAccount"/>
          </a-form-item>
          <a-form-item label="密码" required>
            <a-input v-model:value="userForm.userPassword"/>
          </a-form-item>
          <a-form-item label="性别" required>
            <a-select v-model:value="userForm.gender">
              <a-select-option value="男">男</a-select-option>
              <a-select-option value="女">女</a-select-option>
            </a-select>
          </a-form-item>
          <a-form-item label="年龄" required>
            <a-input-number v-model:value="userForm.age"/>
          </a-form-item>
          <a-form-item label="用户角色" required>
            <a-select v-model:value="userForm.userRole">
              <a-select-option value="1">管理员</a-select-option>
              <a-select-option value="0">普通用户</a-select-option>
              <a-select-option value="2">VIP用户</a-select-option>
              <a-select-option value="3">伍班班长</a-select-option>
              <a-select-option value="5">学习委员</a-select-option>
              <a-select-option value="6">副班长</a-select-option>
              <a-select-option value="7">宣传委员</a-select-option>
              <a-select-option value="8">团支书</a-select-option>
              <a-select-option value="9">副团支书</a-select-option>
              <a-select-option value="10">体育委员</a-select-option>
              <a-select-option value="11">组织委员</a-select-option>
              <a-select-option value="12">劳动委员</a-select-option>
              <a-select-option value="13">心理委员</a-select-option>
              <a-select-option value="3">双创委员</a-select-option>
  
              
            </a-select>
          </a-form-item>
        </a-form>
      </a-modal>
    </config-provider>
  </div>
</template>

<style scoped>

</style>
