import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
// import {jsx} from "vue/jsx-runtime";
// // import jsx from '@vue/babel-plugin-jsx';

export default defineConfig({
  plugins: [vue()],

})
